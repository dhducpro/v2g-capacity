"""Shared, explicit evaluation conventions for the revised manuscript."""
from __future__ import annotations
import hashlib
import json
import platform
import sys
from pathlib import Path
from importlib.metadata import version, PackageNotFoundError
import numpy as np

ROOT = Path(__file__).resolve().parent
PALETTE = {"Deterministic": "#0072B2", "Slotwise Q75": "#E69F00", "Robust": "#009E73",
           "Empirical 90%": "#CC79A7", "Empirical 95%": "#56B4E9", "Conformal 95%": "#D55E00"}
POLICIES = {"Deterministic": 1.0, "Slotwise Q75": 1.25, "Robust": 1.5}
FEAS_TOL = 1e-6
COMP_TOL = 1e-6

def dump_json(path, obj):
    def convert(x):
        if isinstance(x, np.ndarray): return x.tolist()
        if isinstance(x, np.generic): return x.item()
        if isinstance(x, Path): return str(x)
        raise TypeError(type(x).__name__)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(obj, indent=2, default=convert, allow_nan=True), encoding="utf-8")

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def environment():
    import psutil
    cpu = platform.processor()
    if not cpu and Path('/proc/cpuinfo').is_file():
        cpu = next((line.split(':',1)[1].strip() for line in
                    Path('/proc/cpuinfo').read_text().splitlines()
                    if line.startswith('model name')), '')
    packages = {}
    for p in ["numpy", "pandas", "scipy", "cvxpy", "clarabel", "cplex", "pyscipopt", "matplotlib", "psutil"]:
        try: packages[p] = version(p)
        except PackageNotFoundError: packages[p] = None
    return {"platform": platform.platform(), "python": sys.version, "cpu": cpu,
            "logical_cpus": psutil.cpu_count(), "physical_cpus": psutil.cpu_count(logical=False),
            "memory_gib": psutil.virtual_memory().total / 2**30, "packages": packages}

def scalar_metrics(solution):
    """Do not turn failed solves into successful timing observations."""
    return {k: v for k,v in solution.items() if isinstance(v,(str,int,float,bool,np.number)) or v is None}

def station_violation(case, pc, delta=.5, tol=FEAS_TOL):
    """Independent-uniform joint risk, for N=1 only; no rounding of powers."""
    assert case.N == 1
    charge = np.asarray(pc).reshape(-1)
    low=(1-delta)*case.u_nominal.reshape(-1)
    high=(1+delta)*case.u_nominal.reshape(-1)
    # The event uses the same explicitly reported tolerance as simulation.
    thresholds = np.divide(case.M + tol - case.L, charge,
                           out=np.full_like(charge,np.inf),where=charge>1e-12)
    if delta == 0:
        prob=np.where(case.L+case.u_nominal.reshape(-1)*charge<=case.M+tol,1.,0.)
    else:
        prob=np.clip((thresholds-low)/(high-low),0.,1.)
        prob=np.where(charge<=1e-12,(case.L<=case.M+tol).astype(float),prob)
    return float(1-np.prod(prob))

def fleet_risk(case, pc, uniform_draws, delta=.5, tol=FEAS_TOL):
    coeff=case.u_nominal[None,:,:]*(1-delta+2*delta*uniform_draws)
    excess=case.L[None,:]+np.einsum("sit,it->st",coeff,pc,optimize=True)-case.M
    path=excess.max(axis=1)
    count=int(np.count_nonzero(path>tol))
    return {"violation_count":count,"mc_samples":len(path),"violation_probability":count/len(path),
            "mean_positive_excess":float(np.maximum(path,0).mean()),
            "max_sampled_excess":float(np.maximum(path,0).max()),
            "worst_case_excess":float(np.max(case.L+np.sum((1+delta)*case.u_nominal*pc,axis=0)-case.M))}

def setup_plotting():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.family":"DejaVu Sans", "font.size":9, "axes.labelsize":9,
                         "axes.titlesize":10, "legend.fontsize":8, "pdf.fonttype":42,
                         "ps.fonttype":42, "axes.spines.top":False,"axes.spines.right":False})
    return plt
