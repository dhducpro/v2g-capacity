"""One isolated solver call, enabling comparable peak-process-memory measurements."""
import argparse
import json
from pathlib import Path
from revision_model import load_case, solve_case, serialize_result

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--case',required=True)
    p.add_argument('--output',required=True)
    p.add_argument('--solver',default='SCIP')
    p.add_argument('--binary',action='store_true')
    p.add_argument('--policy',choices=['Deterministic','Robust'],default='Deterministic')
    p.add_argument('--time-limit',type=float,default=30.)
    args=p.parse_args()
    # Load native modules outside model/optimization timing in both formulations.
    if args.solver=='SCIP': import pyscipopt
    if args.solver in {'CPLEX','CPLEX_EXE'}: import cplex
    case=load_case(args.case)
    result=solve_case(case,coeff=(1.5 if args.policy=='Robust' else 1.)*case.u_nominal,
                      solver=args.solver,binary=args.binary,time_limit=args.time_limit,threads=1)
    Path(args.output).write_text(json.dumps(serialize_result(result),indent=2,allow_nan=True))

if __name__=='__main__':main()
