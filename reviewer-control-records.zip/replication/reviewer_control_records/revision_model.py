"""Auditable SOC scheduling engine used by the revised manuscript.

All powers and capacities are in kW, energies in kWh, and ``dt`` in hours.
The optimized objective is centered by the fixed baseload penalty; reported
physical objectives and residuals are always recomputed from RAW solver values.
No solver fallback, clipping, or infeasible-run substitution is performed.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any
import json
import math
import os
import re
import subprocess
import threading
import time
import uuid
import xml.etree.ElementTree as ET

import numpy as np


def _array(value: Any, shape: tuple[int, ...], name: str) -> np.ndarray:
    arr = np.asarray(value, dtype=float)
    try:
        result = np.broadcast_to(arr, shape).copy()
    except ValueError as exc:
        raise ValueError(f"{name}: cannot broadcast {arr.shape} to {shape}") from exc
    if not np.isfinite(result).all():
        raise ValueError(f"{name} contains nonfinite values")
    return result


@dataclass
class Case:
    N: int
    T: int
    L: np.ndarray
    availability: np.ndarray
    price_buy: np.ndarray
    price_sell: np.ndarray
    u_nominal: np.ndarray
    Pc: np.ndarray
    Pd: np.ndarray
    E0: np.ndarray
    Emin: np.ndarray
    Emax: np.ndarray
    Etarget: np.ndarray
    eta_c: np.ndarray
    eta_d: np.ndarray
    rho: np.ndarray
    M: float
    alpha: float
    dt: float = 1.0
    name: str = "case"
    metadata: dict = field(default_factory=dict)
    affine_capacity_rows: list[dict] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.N, self.T = int(self.N), int(self.T)
        if self.N < 1 or self.T < 1:
            raise ValueError("N and T must be positive")
        self.L = _array(self.L, (self.T,), "L")
        for key in ("availability", "price_buy", "price_sell", "u_nominal"):
            setattr(self, key, _array(getattr(self, key), (self.N, self.T), key))
        for key in ("Pc", "Pd", "E0", "Emin", "Emax", "Etarget", "eta_c", "eta_d", "rho"):
            setattr(self, key, _array(getattr(self, key), (self.N,), key))
        self.M, self.alpha, self.dt = float(self.M), float(self.alpha), float(self.dt)
        if not all(math.isfinite(x) for x in (self.M, self.alpha, self.dt)):
            raise ValueError("M, alpha and dt must be finite")
        if self.dt <= 0 or self.alpha < 0:
            raise ValueError("dt must be positive and alpha nonnegative")
        if np.any(self.Pc < 0) or np.any(self.Pd < 0) or np.any(self.rho < 0):
            raise ValueError("Power bounds and throughput penalties must be nonnegative")
        if np.any(self.availability < 0) or np.any(self.availability > 1):
            raise ValueError("Availability must lie in [0,1]")
        if np.any(self.eta_c <= 0) or np.any(self.eta_d <= 0) or np.any(self.eta_c > 1) or np.any(self.eta_d > 1):
            raise ValueError("Efficiencies must lie in (0,1]")
        if np.any(self.Emin > self.Emax):
            raise ValueError("Emin exceeds Emax")
        self.metadata = dict(self.metadata)
        # Optional upper rows L+sum(charge*pc-discharge*pd)<=M.  Keeping them
        # inside Case makes native models, LP sidecars and raw diagnostics agree.
        # Empty rows leave all established charging/net-import paths unchanged.
        rows = []
        for number, row in enumerate(self.affine_capacity_rows):
            if not isinstance(row, dict) or not {"charge", "discharge"} <= set(row):
                raise ValueError("Each affine capacity row needs charge and discharge coefficients")
            rows.append({"charge": _array(row["charge"], (self.N, self.T), f"affine charge {number}"),
                         "discharge": _array(row["discharge"], (self.N, self.T), f"affine discharge {number}")})
        self.affine_capacity_rows = rows


def from_legacy(data: Any) -> Case:
    """Convert the original EVData or FleetData without changing its inputs."""
    n = int(getattr(data, "N", 1))
    metadata = {key: getattr(data, key) for key in ("profile_date", "source", "acn_site", "horizon_date", "source_sessions") if hasattr(data, key)}
    return Case(
        N=n, T=data.T, L=data.L, availability=data.availability,
        price_buy=data.price_buy, price_sell=data.price_sell, u_nominal=data.u_nominal,
        Pc=data.X, Pd=data.Y, E0=data.E0, Emin=data.Emin, Emax=data.Emax,
        Etarget=data.Etarget, eta_c=data.eta_c, eta_d=data.eta_d, rho=data.rho,
        M=data.M, alpha=data.alpha, dt=float(getattr(data, "dt", 1.0)),
        name=data.name, metadata=metadata,
    )


def _jsonable(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    return value


def serialize_case(case: Case) -> dict:
    return _jsonable(asdict(case))


def save_case(case: Case, path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(serialize_case(case), indent=2), encoding="utf-8")
    return target


def load_case(path: str | Path) -> Case:
    return Case(**json.loads(Path(path).read_text(encoding="utf-8")))


def serialize_result(result: dict) -> dict:
    """Scalar/tabular summary; omit vector solutions, retain explicit failures."""
    return {key: _jsonable(value) for key, value in result.items()
            if not isinstance(value, np.ndarray) and key not in {"case", "coeff"}}


scalar_result = serialize_result


def certificate_details(case: Case) -> dict:
    """A priori strict cycle-removal certificate for downward-safe constraints.

    Applicable to charging protection with nonnegative coefficients and net-import
    upper bounds, not to a lower/export bound. Values <=0 mean 'not certified',
    never 'inexact'. The bound includes every simultaneously available EV.
    """
    k = case.eta_c * case.eta_d
    net_lower = case.L - np.sum(case.Pd[:, None] * case.availability, axis=0)
    margins = (case.price_buy - k[:, None] * case.price_sell
               + (1 + k[:, None]) * case.rho[:, None]
               + 2 * case.alpha * (1-k[:, None]) * net_lower[None, :])
    active = (case.availability > 0) & (case.Pc[:, None] > 0) & (case.Pd[:, None] > 0)
    minimum = float(np.min(margins[active])) if np.any(active) else float("inf")
    return {"min_margin": minimum, "margins": margins, "net_load_lower_bound": net_lower,
            "strictly_certified": bool(minimum > 0), "has_bidirectional_slots": bool(np.any(active)),
            "scope": "charging protection with nonnegative coefficients or net-import upper bound; not two-sided constraints"}


def certificate_min(case: Case) -> float:
    return certificate_details(case)["min_margin"]


class _MemorySampler:
    """Sample process-tree RSS during one call, including model construction.

    This is process memory (including interpreter), not solver-owned memory.
    The 5 ms sampler may miss a short transient; report this method explicitly.
    """
    def __enter__(self):
        import psutil
        self.process = psutil.Process()
        self.child_peak = 0.0
        def rss():
            own = self.process.memory_info().rss / 2**20
            child = 0.0
            for process in self.process.children(recursive=True):
                try:
                    child += process.memory_info().rss / 2**20
                except psutil.Error:
                    pass
            self.child_peak = max(self.child_peak, child)
            return own + child
        self.rss = rss
        self.initial = self.rss()
        self.peak = self.initial
        self.stop_event = threading.Event()
        def sample():
            while not self.stop_event.wait(0.005):
                try:
                    self.peak = max(self.peak, self.rss())
                except psutil.Error:
                    break
        self.thread = threading.Thread(target=sample, daemon=True)
        self.thread.start()
        return self

    def __exit__(self, *args):
        self.peak = max(self.peak, self.rss())
        self.stop_event.set()
        self.thread.join(timeout=1)


def _coefficient(case: Case, coeff: Any) -> np.ndarray:
    return _array(case.u_nominal if coeff is None else coeff, (case.N, case.T), "coeff")


def _validate_mode(mode: str, export_limit: float | None) -> None:
    if mode not in {"charging", "net_import", "two_sided", "affine"}:
        raise ValueError(f"Unknown capacity_mode: {mode}")
    if mode == "two_sided" and (export_limit is None or not math.isfinite(float(export_limit)) or export_limit < 0):
        raise ValueError("two_sided requires a finite nonnegative export_limit")


def _validate_affine_rows(case: Case, mode: str) -> None:
    if mode == "affine" and not case.affine_capacity_rows:
        raise ValueError("affine capacity_mode requires at least one affine_capacity_rows entry")


def _preserves_cycles(case: Case, coeff: np.ndarray, mode: str) -> bool:
    """Check the actual constraint rows, independently of the objective margin."""
    if mode == "affine":
        _validate_affine_rows(case, mode)
        k = (case.eta_c * case.eta_d)[:, None]
        return all(bool(np.all(row["charge"] - k * row["discharge"] >= 0))
                   for row in case.affine_capacity_rows)
    return bool(mode == "net_import" or (mode == "charging" and np.all(coeff >= 0)))


def _validate_qp_method(qp_method: int | None) -> int | None:
    """Validate an explicit Interactive Optimizer QP override; None preserves defaults."""
    if qp_method is None:
        return None
    if (isinstance(qp_method, bool) or not isinstance(qp_method, (int, np.integer))
            or int(qp_method) not in {0, 1, 2, 3, 4, 6}):
        raise ValueError("qp_method must be None or a CPLEX QP method in {0,1,2,3,4,6}")
    return int(qp_method)


def diagnose_solution(case: Case, pc: Any, pd: Any, energy: Any, *, coeff=None,
                      capacity_mode="charging", export_limit=None) -> dict:
    """Recompute physical quantities on unrounded solver values."""
    _validate_mode(capacity_mode, export_limit)
    _validate_affine_rows(case, capacity_mode)
    coeff = _coefficient(case, coeff)
    pc = np.asarray(pc, dtype=float).reshape(case.N, case.T).copy()
    pd = np.asarray(pd, dtype=float).reshape(case.N, case.T).copy()
    energy = np.asarray(energy, dtype=float).reshape(case.N, case.T+1).copy()
    net = case.L + np.sum(pc-pd, axis=0)
    ecost = float(case.dt * np.sum(case.price_buy*pc-case.price_sell*pd))
    through = float(case.dt * np.sum(case.rho[:, None]*(pc+pd)))
    smoothing = float(case.dt * case.alpha * np.sum(net**2))
    baseline = float(case.dt * case.alpha * np.sum(case.L**2))
    # Compute centered form directly to avoid subtracting two large constants.
    evnet = np.sum(pc-pd, axis=0)
    centered = ecost+through+float(case.dt*case.alpha*np.sum(2*case.L*evnet+evnet**2))
    soc = energy[:, 1:]-energy[:, :-1]-case.dt*(case.eta_c[:, None]*pc-pd/case.eta_d[:, None])
    capacity_rows = None
    if capacity_mode == "affine":
        capacity_rows = np.stack([case.L + np.sum(row["charge"]*pc-row["discharge"]*pd, axis=0)
                                  for row in case.affine_capacity_rows])
        capacity = np.max(capacity_rows, axis=0)
    else:
        capacity = case.L + np.sum(coeff*pc, axis=0) if capacity_mode == "charging" else net
    power_violations = [0.0, float(np.max(-pc)), float(np.max(-pd)),
        float(np.max(pc-case.Pc[:, None]*case.availability)),
        float(np.max(pd-case.Pd[:, None]*case.availability)),float(np.max(capacity-case.M))]
    energy_violations = [0.0,float(np.max(np.abs(energy[:, 0]-case.E0))), float(np.max(np.abs(soc))),
        float(np.max(case.Emin[:, None]-energy[:, 1:])),
        float(np.max(energy[:, 1:]-case.Emax[:, None])),
        float(np.max(case.Etarget-energy[:, -1]))]
    if capacity_mode == "two_sided":
        power_violations.append(float(np.max(-float(export_limit)-net)))
    result = {"pc": pc, "pd": pd, "energy": energy, "net_load": net,
        "protected_load": capacity, "objective_full": centered+baseline,
        "objective_linear": ecost+through, "energy_cost": ecost,
        "throughput_cost": through, "load_smoothing": smoothing,
        "objective_centered": centered, "baseline_constant": baseline,
        "simultaneous_residual_raw": float(max(0.0, np.max(np.minimum(pc, pd)))),
        "simultaneous_product_raw": float(max(0.0, np.max(pc*pd))),
        "feasibility_residual": float(max(power_violations+energy_violations)), "soc_residual": float(np.max(np.abs(soc))),
        "max_power_residual_kw":float(max(power_violations)),"max_energy_residual_kwh":float(max(energy_violations)),
        "total_charge_kwh": float(case.dt*np.sum(pc)), "total_discharge_kwh": float(case.dt*np.sum(pd)),
        "min_net_load": float(np.min(net)), "max_net_load": float(np.max(net)),
        "min_terminal_surplus": float(np.min(energy[:, -1]-case.Etarget))}
    if capacity_rows is not None:
        result["protected_load_rows"] = capacity_rows
    return result


def _blank(case: Case, solver: str, binary: bool, mode: str) -> dict:
    return {"name": case.name, "N": case.N, "T": case.T, "dt": case.dt,
        "solver": solver, "binary": bool(binary), "capacity_mode": mode,
        "status": "not_solved", "has_solution": False,
        "objective_full": math.nan, "objective_linear": math.nan,
        "energy_cost": math.nan, "throughput_cost": math.nan, "load_smoothing": math.nan,
        "objective_centered": math.nan,
        "baseline_constant": float(case.dt*case.alpha*np.sum(case.L**2)),
        "simultaneous_residual_raw": math.nan, "feasibility_residual": math.nan,
        "soc_residual": math.nan, "solve_time_sec": math.nan,
        "solver_peak_memory_mb": math.nan, "bound_centered": math.nan,
        "bound_full": math.nan, "mip_gap": math.nan,
        "certificate_min": certificate_min(case)}


def _cvxpy(case, coeff, solver, binary, time_limit, threads, seed, mode, export_limit):
    import cvxpy as cp
    if binary:
        raise ValueError(f"{solver} is the continuous QP engine; use native CPLEX or SCIP for binary runs")
    started = time.perf_counter()
    pc = cp.Variable((case.N, case.T), nonneg=True)
    pd = cp.Variable((case.N, case.T), nonneg=True)
    E = cp.Variable((case.N, case.T+1))
    evnet = cp.sum(pc-pd, axis=0)
    energy_cost = cp.sum(cp.multiply(case.price_buy, pc)-cp.multiply(case.price_sell, pd))
    throughput = cp.sum(cp.multiply(case.rho[:, None], pc+pd))
    obj = case.dt*(energy_cost+throughput+case.alpha*(2*case.L@evnet+cp.sum_squares(evnet)))
    constraints = [pc <= case.Pc[:, None]*case.availability, pd <= case.Pd[:, None]*case.availability,
        E[:, 0] == case.E0,
        E[:, 1:] == E[:, :-1]+case.dt*(cp.multiply(case.eta_c[:, None], pc)-cp.multiply(1/case.eta_d[:, None], pd)),
        E[:, 1:] >= case.Emin[:, None], E[:, 1:] <= case.Emax[:, None], E[:, -1] >= case.Etarget]
    if mode == "charging":
        constraints.append(case.L+cp.sum(cp.multiply(coeff, pc), axis=0) <= case.M)
    elif mode == "affine":
        for row in case.affine_capacity_rows:
            constraints.append(case.L + cp.sum(cp.multiply(row["charge"], pc)
                                               - cp.multiply(row["discharge"], pd), axis=0) <= case.M)
    else:
        constraints.append(case.L+evnet <= case.M)
        if mode == "two_sided":
            constraints.append(case.L+evnet >= -float(export_limit))
    problem = cp.Problem(cp.Minimize(obj), constraints)
    built = time.perf_counter()
    kwargs = {"solver": solver, "verbose": False, "warm_start": False}
    if solver == "CLARABEL":
        kwargs.update(tol_gap_abs=1e-9, tol_gap_rel=1e-9, tol_feas=1e-9, max_iter=400, time_limit=float(time_limit), max_threads=int(threads))
    elif solver == "OSQP":
        kwargs.update(eps_abs=1e-8, eps_rel=1e-8, max_iter=200000, polish=True, time_limit=float(time_limit))
    else:
        raise ValueError(f"Unsupported continuous solver: {solver}")
    problem.solve(**kwargs)
    elapsed = time.perf_counter()-built
    result = {"status": str(problem.status), "raw_status": str(problem.status),
        "model_build_time_sec": built-started, "solve_time_sec": float(problem.solver_stats.solve_time or elapsed),
        "solve_wall_time_sec": elapsed, "solver_objective_centered": float(problem.value) if problem.value is not None else math.nan,
        "solver_version": "", "num_binary_variables": 0,
        "num_variables": int(problem.size_metrics.num_scalar_variables)}
    if pc.value is not None and pd.value is not None and E.value is not None:
        result.update(diagnose_solution(case, pc.value, pd.value, E.value, coeff=coeff, capacity_mode=mode, export_limit=export_limit))
        result["has_solution"] = True
        if problem.status == cp.OPTIMAL:
            result["bound_centered"] = float(problem.value)
    try:
        from importlib.metadata import version
        result["solver_version"] = version(solver.lower())
    except Exception:
        pass
    return result


def _build_cplex(case, coeff, binary, time_limit, threads, seed, mode, export_limit):
    import cplex
    model = cplex.Cplex()
    model.set_log_stream(None); model.set_error_stream(None)
    model.set_warning_stream(None); model.set_results_stream(None)
    model.objective.set_sense(model.objective.sense.minimize)
    model.parameters.threads.set(int(threads))
    model.parameters.randomseed.set(int(seed))
    model.parameters.timelimit.set(float(time_limit))
    model.parameters.advance.set(0)
    model.parameters.simplex.tolerances.feasibility.set(1e-9)
    model.parameters.simplex.tolerances.optimality.set(1e-9)
    model.parameters.barrier.convergetol.set(1e-10)
    model.parameters.mip.tolerances.integrality.set(1e-9)
    model.parameters.mip.tolerances.mipgap.set(1e-8)
    model.parameters.mip.tolerances.absmipgap.set(1e-7)
    names, lower, upper, cost, types = [], [], [], [], []
    pc_idx = np.full((case.N, case.T), -1, dtype=int)
    pd_idx = pc_idx.copy(); z_idx = pc_idx.copy()
    E_idx = np.empty((case.N, case.T+1), dtype=int)
    def add(name, lo, hi, c=0.0, kind="C"):
        idx = len(names); names.append(name); lower.append(float(lo)); upper.append(float(hi)); cost.append(float(c)); types.append(kind)
        return idx
    for i in range(case.N):
        for t in range(case.T):
            xbound, ybound = case.Pc[i]*case.availability[i,t], case.Pd[i]*case.availability[i,t]
            if xbound > 0:
                pc_idx[i,t] = add(f"pc_{i}_{t}", 0, xbound, case.dt*(case.price_buy[i,t]+case.rho[i]))
            if ybound > 0:
                pd_idx[i,t] = add(f"pd_{i}_{t}", 0, ybound, case.dt*(-case.price_sell[i,t]+case.rho[i]))
            if binary and xbound > 0 and ybound > 0:
                z_idx[i,t] = add(f"z_{i}_{t}", 0, 1, kind="B")
        for t in range(case.T+1):
            E_idx[i,t] = add(f"state_{i}_{t}", case.E0[i] if t==0 else case.Emin[i], case.E0[i] if t==0 else case.Emax[i])
    s_idx = np.array([add(f"s_{t}", -np.sum(case.Pd*case.availability[:,t]), np.sum(case.Pc*case.availability[:,t]), 2*case.dt*case.alpha*case.L[t]) for t in range(case.T)])
    kwargs = dict(obj=cost, lb=lower, ub=upper, names=names)
    if binary and "B" in types:
        kwargs["types"] = "".join(types)
    model.variables.add(**kwargs)
    if case.alpha > 0:
        model.objective.set_quadratic_coefficients([(int(j), int(j), 2*case.dt*case.alpha) for j in s_idx])
    rows, senses, rhs, row_names = [], [], [], []
    def row(terms, sense, right, name):
        terms = [(int(j), float(v)) for j,v in terms if j >= 0 and v != 0]
        rows.append(cplex.SparsePair(ind=[j for j,v in terms], val=[v for j,v in terms]))
        senses.append(sense); rhs.append(float(right)); row_names.append(name)
    for i in range(case.N):
        for t in range(case.T):
            row([(E_idx[i,t+1],1),(E_idx[i,t],-1),(pc_idx[i,t],-case.dt*case.eta_c[i]),(pd_idx[i,t],case.dt/case.eta_d[i])], "E",0,f"soc_{i}_{t}")
            if z_idx[i,t] >= 0:
                row([(pc_idx[i,t],1),(z_idx[i,t],-case.Pc[i]*case.availability[i,t])],"L",0,f"modec_{i}_{t}")
                row([(pd_idx[i,t],1),(z_idx[i,t],case.Pd[i]*case.availability[i,t])],"L",case.Pd[i]*case.availability[i,t],f"moded_{i}_{t}")
        row([(E_idx[i,-1],1)],"G",case.Etarget[i],f"target_{i}")
    for t in range(case.T):
        row([(s_idx[t],1)]+[(pc_idx[i,t],-1) for i in range(case.N)]+[(pd_idx[i,t],1) for i in range(case.N)],"E",0,f"net_{t}")
        if mode == "charging":
            row([(pc_idx[i,t],coeff[i,t]) for i in range(case.N)],"L",case.M-case.L[t],f"cap_{t}")
        elif mode == "affine":
            for number, impact in enumerate(case.affine_capacity_rows):
                row([(pc_idx[i,t],impact["charge"][i,t]) for i in range(case.N)]
                    + [(pd_idx[i,t],-impact["discharge"][i,t]) for i in range(case.N)],
                    "L",case.M-case.L[t],f"cap_affine_{number}_{t}")
        else:
            row([(s_idx[t],1)],"L",case.M-case.L[t],f"cap_{t}")
            if mode == "two_sided":
                row([(s_idx[t],1)],"G",-float(export_limit)-case.L[t],f"export_{t}")
    model.linear_constraints.add(lin_expr=rows,senses="".join(senses),rhs=rhs,names=row_names)
    return model, {"pc":pc_idx,"pd":pd_idx,"energy":E_idx,"z":z_idx,"net":s_idx,"names":names}


def _native_cplex(case, coeff, binary, time_limit, threads, seed, mode, export_limit, qp_method=None):
    started=time.perf_counter()
    model, index = _build_cplex(case, coeff, binary, time_limit, threads, seed, mode, export_limit)
    if qp_method is not None:
        model.parameters.qpmethod.set(qp_method)
    built=time.perf_counter()
    result={"solver_version":model.get_version(),"model_build_time_sec":built-started,
            "num_variables":model.variables.get_num(),"num_binary_variables":int(np.sum(index["z"]>=0))}
    try:
        model.solve()
    except Exception as exc:
        result.update(status="solver_error",raw_status=type(exc).__name__,error=str(exc),solve_time_sec=time.perf_counter()-built,solve_wall_time_sec=time.perf_counter()-built)
        model.end()
        return result
    result["solve_time_sec"]=time.perf_counter()-built
    result["solve_wall_time_sec"]=result["solve_time_sec"]
    raw=model.solution.get_status_string()
    result["raw_status"]=raw
    has_solution=bool(model.solution.is_primal_feasible())
    low=raw.lower()
    if "optimal" in low and "infeasib" not in low:
        result["status"]="optimal"
    elif "optimal" in low and "infeasib" in low:
        result["status"]="invalid_solver_solution"
    elif "infeasible or unbounded" in low:
        result["status"]="infeasible_or_unbounded"
    elif "infeasible" in low and not has_solution:
        result["status"]="infeasible"
    elif "unbounded" in low:
        result["status"]="unbounded"
    elif "time limit" in low:
        result["status"]="time_limit_feasible" if has_solution else "time_limit_no_solution"
    else:
        result["status"]="feasible_limit" if has_solution else "no_solution"
    if has_solution:
        values=np.asarray(model.solution.get_values(),dtype=float)
        def extract(idx):
            out=np.zeros(idx.shape); mask=idx>=0; out[mask]=values[idx[mask]]; return out
        result.update(diagnose_solution(case,extract(index["pc"]),extract(index["pd"]),extract(index["energy"]),coeff=coeff,capacity_mode=mode,export_limit=export_limit))
        result["has_solution"]=True
        result["solver_objective_centered"]=float(model.solution.get_objective_value())
        if result["num_binary_variables"]:
            result["bound_centered"]=float(model.solution.MIP.get_best_objective())
            result["mip_gap"]=float(model.solution.MIP.get_mip_relative_gap())
            result["nodes"]=int(model.solution.progress.get_num_nodes_processed())
            z=extract(index["z"]); result["mode_integrality_residual"]=float(np.max(np.abs(z-np.rint(z))))
        elif result["status"]=="optimal":
            result["bound_centered"]=result["solver_objective_centered"]
    model.end()
    return result


def _native_scip(case, coeff, binary, time_limit, threads, seed, mode, export_limit):
    from pyscipopt import Model, quicksum
    started=time.perf_counter(); model=Model(case.name)
    model.hideOutput(); model.setRealParam("limits/time",float(time_limit))
    model.setRealParam("limits/gap",1e-8); model.setRealParam("limits/absgap",1e-7)
    model.setRealParam("numerics/feastol",1e-8)
    model.setIntParam("parallel/maxnthreads",int(threads))
    model.setIntParam("lp/threads",int(threads))
    model.setIntParam("randomization/randomseedshift",int(seed)%2147483647)
    pc=np.empty((case.N,case.T),dtype=object);pd=pc.copy();z=pc.copy();E=np.empty((case.N,case.T+1),dtype=object)
    pc[:]=None;pd[:]=None;z[:]=None
    def v(value):return 0.0 if value is None else value
    for i in range(case.N):
        for t in range(case.T):
            xb,yb=case.Pc[i]*case.availability[i,t],case.Pd[i]*case.availability[i,t]
            if xb>0:pc[i,t]=model.addVar(name=f"pc_{i}_{t}",lb=0,ub=float(xb))
            if yb>0:pd[i,t]=model.addVar(name=f"pd_{i}_{t}",lb=0,ub=float(yb))
            if binary and xb>0 and yb>0:
                z[i,t]=model.addVar(name=f"z_{i}_{t}",vtype="B")
                model.addCons(pc[i,t]<=float(xb)*z[i,t],name=f"modec_{i}_{t}")
                model.addCons(pd[i,t]<=float(yb)*(1-z[i,t]),name=f"moded_{i}_{t}")
        for t in range(case.T+1):
            E[i,t]=model.addVar(name=f"E_{i}_{t}",lb=float(case.E0[i] if t==0 else case.Emin[i]),ub=float(case.E0[i] if t==0 else case.Emax[i]))
        for t in range(case.T):
            model.addCons(E[i,t+1]-E[i,t]==case.dt*(case.eta_c[i]*v(pc[i,t])-v(pd[i,t])/case.eta_d[i]),name=f"soc_{i}_{t}")
        model.addCons(E[i,-1]>=float(case.Etarget[i]),name=f"target_{i}")
    net=[]
    for t in range(case.T):
        s=model.addVar(name=f"s_{t}",lb=-float(np.sum(case.Pd*case.availability[:,t])),ub=float(np.sum(case.Pc*case.availability[:,t])))
        model.addCons(s==quicksum(v(pc[i,t])-v(pd[i,t]) for i in range(case.N)),name=f"net_{t}")
        net.append(s)
        if mode=="charging":
            model.addCons(quicksum(coeff[i,t]*v(pc[i,t]) for i in range(case.N))<=float(case.M-case.L[t]),name=f"cap_{t}")
        elif mode=="affine":
            for number, impact in enumerate(case.affine_capacity_rows):
                model.addCons(quicksum(impact["charge"][i,t]*v(pc[i,t])-impact["discharge"][i,t]*v(pd[i,t])
                                       for i in range(case.N)) <= float(case.M-case.L[t]),name=f"cap_affine_{number}_{t}")
        else:
            model.addCons(s<=float(case.M-case.L[t]),name=f"cap_{t}")
            if mode=="two_sided":model.addCons(s>=float(-export_limit-case.L[t]),name=f"export_{t}")
    obj=case.dt*quicksum((case.price_buy[i,t]+case.rho[i])*v(pc[i,t])+(-case.price_sell[i,t]+case.rho[i])*v(pd[i,t]) for i in range(case.N) for t in range(case.T))
    if case.alpha>0:
        q=model.addVar(name="quadratic_epigraph",lb=0)
        model.addCons(q>=case.dt*case.alpha*quicksum(s*s for s in net),name="smoothing_epigraph")
        obj+=q+quicksum(2*case.dt*case.alpha*case.L[t]*net[t] for t in range(case.T))
    model.setObjective(obj,"minimize")
    nvars=model.getNVars(); nbinary=sum(value is not None for value in z.ravel());built=time.perf_counter()
    model.optimize()
    raw=str(model.getStatus()); has_solution=model.getNSols()>0
    status="optimal" if raw=="optimal" else ("time_limit_feasible" if has_solution else "time_limit_no_solution") if raw=="timelimit" else raw
    result={"status":status,"raw_status":raw,"has_solution":has_solution,
        "solver_version":f"{model.getMajorVersion()}.{model.getMinorVersion()}.{model.getTechVersion()}",
        "model_build_time_sec":built-started,"solve_time_sec":float(model.getSolvingTime()),
        "solve_wall_time_sec":time.perf_counter()-built,"num_variables":int(nvars),"num_binary_variables":int(nbinary),
        "solver_peak_memory_mb":math.nan,"solver_memory_mb_at_end":float(model.getMemTotal())/2**20,
        "nodes":int(model.getNNodes()),"bound_centered":float(model.getDualbound())}
    if has_solution:
        sol=model.getBestSol()
        def extract(arr):return np.array([0.0 if value is None else model.getSolVal(sol,value) for value in arr.ravel()]).reshape(arr.shape)
        result.update(diagnose_solution(case,extract(pc),extract(pd),extract(E),coeff=coeff,capacity_mode=mode,export_limit=export_limit))
        result["solver_objective_centered"]=float(model.getSolObjVal(sol));result["mip_gap"]=float(model.getGap())
        if binary:
            zz=extract(z);result["mode_integrality_residual"]=float(np.max(np.abs(zz-np.rint(zz))))
    model.freeProb()
    return result


def solve_case(case: Case, coeff=None, solver="CLARABEL", binary=False,
               time_limit=60, threads=1, seed=0, capacity_mode="charging",
               export_limit=None, qp_method=None) -> dict:
    """Solve one case. Errors and limits remain visible, never silently replaced.

    ``charging`` protects L+sum(coeff*pc). ``net_import`` and ``two_sided``
    constrain physical L+sum(pc-pd), intentionally ignoring ``coeff``.
    ``feasibility_residual`` excludes complementarity, which is reported separately;
    it is a legacy mixed-unit maximum. Prefer the separate power/energy residuals.
    ``affine`` uses every explicit Case.affine_capacity_rows entry and ignores
    ``coeff``.  ``qp_method`` optionally overrides native or executable CPLEX;
    None leaves every existing solver default unchanged.
    """
    started=time.perf_counter();solver=str(solver).upper()
    _validate_mode(capacity_mode,export_limit); coeff=_coefficient(case,coeff)
    _validate_affine_rows(case,capacity_mode)
    qp_method=_validate_qp_method(qp_method)
    if qp_method is not None and solver not in {"CPLEX", "CPLEX_EXE"}:
        raise ValueError("qp_method overrides are supported only for CPLEX or CPLEX_EXE")
    result=_blank(case,solver,binary,capacity_mode)
    if qp_method is not None:
        result.update(requested_qp_method=qp_method,qpmethod=qp_method)
    applicable=_preserves_cycles(case,coeff,capacity_mode)
    result.update(time_limit_sec=float(time_limit),threads=int(threads),seed=int(seed),
        certificate_applicable=applicable,strictly_certified=bool(applicable and result["certificate_min"]>0),
        coefficients_used=capacity_mode in {"charging", "affine"},memory_measurement="process-tree RSS sampled every 5 ms, including construction")
    with _MemorySampler() as memory:
        try:
            if solver=="CPLEX":details=_native_cplex(case,coeff,binary,time_limit,threads,seed,capacity_mode,export_limit,qp_method=qp_method)
            elif solver=="CPLEX_EXE":details=_cplex_exe(case,coeff,binary,time_limit,threads,seed,capacity_mode,export_limit,qp_method=qp_method)
            elif solver=="SCIP":details=_native_scip(case,coeff,binary,time_limit,threads,seed,capacity_mode,export_limit)
            else:details=_cvxpy(case,coeff,solver,binary,time_limit,threads,seed,capacity_mode,export_limit)
            result.update(details)
        except Exception as exc:
            result.update(status="solver_error",raw_status=type(exc).__name__,error=str(exc))
    result.update(wall_time_sec=time.perf_counter()-started,peak_rss_mb=memory.peak,
        baseline_rss_mb=memory.initial,peak_rss_increase_mb=max(0.0,memory.peak-memory.initial),
        external_solver_peak_rss_mb=memory.child_peak)
    if math.isfinite(result.get("bound_centered",math.nan)):
        result["bound_full"]=result["bound_centered"]+result["baseline_constant"]
    return result


def export_cplex_lp(case: Case, path: str | Path, binary=False, coeff=None,
                    capacity_mode="charging", export_limit=None,
                    time_limit=60, threads=1, seed=0, qp_method=None) -> dict:
    """Export an identical native QP/MIQP and a self-contained JSON sidecar.

    Model writing does not solve and is not subject to Community solve-size limits.
    CPLEX CLI solutions can be passed to read_cplex_solution for raw diagnostics.
    An optional qp_method is recorded as a requested run setting in the sidecar;
    LP files do not carry the Interactive Optimizer's parameter commands.
    """
    target=Path(path);target.parent.mkdir(parents=True,exist_ok=True)
    _validate_mode(capacity_mode,export_limit);coeff=_coefficient(case,coeff)
    _validate_affine_rows(case,capacity_mode)
    qp_method=_validate_qp_method(qp_method)
    model,index=_build_cplex(case,coeff,binary,time_limit,threads,seed,capacity_mode,export_limit)
    model.write(str(target))
    metadata={"case":serialize_case(case),"coeff":coeff.tolist(),"binary":bool(binary),
        "capacity_mode":capacity_mode,"export_limit":export_limit,"time_limit":float(time_limit),
        "threads":int(threads),"seed":int(seed),"objective":"centered", "solver_export_version":model.get_version(),
        "num_variables":model.variables.get_num(),"num_binary_variables":int(np.sum(index["z"]>=0))}
    if qp_method is not None:
        metadata["requested_qp_method"]=qp_method
    sidecar=target.with_suffix(target.suffix+".json")
    sidecar.write_text(json.dumps(metadata,indent=2),encoding="utf-8");model.end()
    return {"model_path":str(target),"metadata_path":str(sidecar),**{k:metadata[k] for k in ("num_variables","num_binary_variables")}}


def read_cplex_solution(path: str | Path, case: Case | None=None, *, metadata_path=None,
                        coeff=None, binary=None, capacity_mode="charging",export_limit=None) -> dict:
    """Read a CPLEX XML .sol and recompute objective and raw residuals.

    Pass the .lp.json sidecar for complete reproducibility. Sparse solution XML
    omissions are zeros, as in the CPLEX format. Wall time/memory require CLI logs.
    """
    metadata={}
    if metadata_path is not None:
        metadata=json.loads(Path(metadata_path).read_text(encoding="utf-8"))
        case=Case(**metadata["case"]) if case is None else case
        coeff=metadata["coeff"] if coeff is None else coeff
        binary=metadata["binary"] if binary is None else binary
        capacity_mode=metadata["capacity_mode"];export_limit=metadata["export_limit"]
    if case is None:raise ValueError("Provide case or metadata_path")
    root=ET.parse(path).getroot();header=root.find("header")
    if header is None:raise ValueError("CPLEX solution lacks a header")
    raw=header.get("solutionStatusString","")
    # LP writers may append #original_index to all names when escaping a name.
    # Older exports used E_*; CPLEX escapes that reserved prefix as _E_*.
    def canonical(name):
        name=re.sub(r"#\d+$","",name)
        return name[1:] if name.startswith("_E_") else name
    values={canonical(v.attrib["name"]):float(v.attrib["value"]) for v in root.findall("./variables/variable")}
    pc=np.array([[values.get(f"pc_{i}_{t}",0.0) for t in range(case.T)] for i in range(case.N)])
    pd=np.array([[values.get(f"pd_{i}_{t}",0.0) for t in range(case.T)] for i in range(case.N)])
    E=np.array([[values.get(f"state_{i}_{t}",values.get(f"E_{i}_{t}",0.0)) for t in range(case.T+1)] for i in range(case.N)])
    result=_blank(case,"CPLEX_CLI",bool(binary),capacity_mode)
    applicable=_preserves_cycles(case,_coefficient(case,coeff),capacity_mode)
    result.update(certificate_applicable=applicable,strictly_certified=bool(applicable and result["certificate_min"]>0))
    result.update(diagnose_solution(case,pc,pd,E,coeff=coeff,capacity_mode=capacity_mode,export_limit=export_limit))
    low=raw.lower()
    parsed_status=("invalid_solver_solution" if "infeasib" in low else
                   "optimal" if "optimal" in low else "feasible_limit")
    result.update(raw_status=raw,status=parsed_status,has_solution=True,
        solver_objective_centered=float(header.get("objectiveValue","nan")),solution_path=str(path))
    if "bestObjective" in header.attrib:
        result["bound_centered"]=float(header.get("bestObjective"));result["bound_full"]=result["bound_centered"]+result["baseline_constant"]
    if "MIPRelativeGap" in header.attrib:result["mip_gap"]=float(header.get("MIPRelativeGap"))
    if result["status"]=="optimal" and not binary and not math.isfinite(result["bound_centered"]):
        result["bound_centered"]=result["solver_objective_centered"];result["bound_full"]=result["bound_centered"]+result["baseline_constant"]
    result["objective_reconstruction_error"]=abs(result["objective_centered"]-result["solver_objective_centered"])
    if result["objective_reconstruction_error"] > 1e-5*max(1.0,abs(result["solver_objective_centered"])):
        result["status"]="invalid_solution_reconstruction"
    result["metadata_source"]=str(metadata_path) if metadata_path is not None else ""
    return result


def _cplex_command_text(lp, sol, time_limit, threads, seed, qp_method=None):
    """Build the retained Interactive commands without launching an executable."""
    qp_method=_validate_qp_method(qp_method)
    def quoted(path):return '"'+str(Path(path).resolve()).replace('"','')+'"'
    commands=[
        "read "+quoted(lp),
        f"set threads {int(threads)}",f"set randomseed {int(seed)}",f"set timelimit {float(time_limit):.12g}",
        "set advance 0","set simplex tolerances feasibility 1e-9","set simplex tolerances optimality 1e-9",
        "set barrier convergetol 1e-10","set mip tolerances integrality 1e-9",
        "set mip tolerances mipgap 1e-8","set mip tolerances absmipgap 1e-7"]
    if qp_method is not None:
        commands.append(f"set qpmethod {qp_method}")
    commands.extend(["optimize","display solution quality","write "+quoted(sol),"quit",""])
    return "\n".join(commands)


def _cplex_exe(case, coeff, binary, time_limit, threads, seed, mode, export_limit, qp_method=None):
    """Use the user's independently licensed CPLEX interactive executable.

    The executable route is prepared for Windows but is not claimed tested there.
    Model export uses the pip CPLEX API; exporting itself has no solve-size limit.
    Logs, command input, model, metadata and solution are retained for every run.
    """
    qp_method=_validate_qp_method(qp_method)
    method_info={} if qp_method is None else {"requested_qp_method":qp_method,"qpmethod":qp_method}
    default = r"C:\Program Files\IBM\ILOG\CPLEX_Studio2212\cplex\bin\x64_win64\cplex.exe"
    exe = os.environ.get("V2G_CPLEX_EXE", default)
    if not Path(exe).is_file():
        return {"status":"solver_error","raw_status":"executable_not_found",
            "error":f"CPLEX executable does not exist on this host: {exe}. Set V2G_CPLEX_EXE to the installed executable; no fallback was run.",
            "solver_executable":exe,"solver_version":"unobserved",**method_info}
    started=time.perf_counter()
    root=Path(os.environ.get("V2G_CPLEX_OUTPUT_DIR",str(Path(__file__).resolve().parent/"logs"/"cplex_exe")))
    safe=re.sub(r"[^A-Za-z0-9_.-]","_",case.name)[:70]
    folder=root/f"{safe}_{'miqp' if binary else 'qp'}_{mode}_{uuid.uuid4().hex[:10]}"
    folder.mkdir(parents=True,exist_ok=False)
    lp=folder/"model.lp"; sol=folder/"solution.sol"; logfile=folder/"solver.log"; commandsfile=folder/"commands.txt"
    bundle=export_cplex_lp(case,lp,binary=binary,coeff=coeff,capacity_mode=mode,export_limit=export_limit,time_limit=time_limit,threads=threads,seed=seed,qp_method=qp_method)
    commands=_cplex_command_text(lp,sol,time_limit,threads,seed,qp_method)
    commandsfile.write_text(commands,encoding="utf-8")
    built=time.perf_counter()
    result={"solver":"CPLEX_EXE","solver_executable":exe,"solver_version":"unobserved",
        "model_build_time_sec":built-started,"model_path":str(lp),"metadata_path":bundle["metadata_path"],
        "log_path":str(logfile),"commands_path":str(commandsfile),
        "num_variables":bundle["num_variables"],"num_binary_variables":bundle["num_binary_variables"],**method_info}
    process=None
    try:
        process=subprocess.Popen([exe],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
            text=True,encoding="utf-8",errors="replace",cwd=str(folder))
        output,_=process.communicate(commands,timeout=float(time_limit)+120.0)
        result["executable_returncode"]=process.returncode
        result["execution_status"]="completed" if process.returncode == 0 else "solver_error"
        if process.returncode != 0:
            result.update(status="solver_error",raw_status="executable_nonzero_returncode",
                error=f"CPLEX executable exited with return code {process.returncode}; any saved solution is retained separately.")
    except subprocess.TimeoutExpired:
        process.kill();output,_=process.communicate()
        result.update(status="external_timeout",execution_status="external_timeout",
            executable_returncode=process.returncode,raw_status="executable_exceeded_solver_limit_plus_120s",
            error="CPLEX executable did not terminate within the external wall-time guard.")
    except Exception as exc:
        output=str(exc);result.update(status="solver_error",execution_status="solver_error",raw_status=type(exc).__name__,error=str(exc))
    elapsed=time.perf_counter()-built
    logfile.write_text(output,encoding="utf-8")
    result.update(solve_wall_time_sec=elapsed,solve_time_sec=math.nan)
    version=re.search(r"(?:Version|version)\s*:?\s*(\d+(?:\.\d+){1,3})",output)
    if version:result["solver_version"]=version.group(1)
    timing=re.findall(r"(?:Solution|Solve) time\s*=\s*([0-9.eE+\-]+)\s*sec",output,re.I)
    if timing:result["solve_time_sec"]=float(timing[-1])
    if sol.is_file():
        process_failure={key:result[key] for key in ("status","raw_status","error") if key in result}
        parsed=read_cplex_solution(sol,metadata_path=bundle["metadata_path"])
        result["saved_solution_status"]=parsed["status"]
        result["saved_solution_raw_status"]=parsed["raw_status"]
        parsed.pop("solver",None);result.update(parsed)
        # A saved primal remains inspectable after interruption or a nonzero
        # exit, but it must not turn a failed executable run into a success.
        result.update(process_failure)
        # read_cplex_solution has unknown timings, so restore observed CLI values.
        result["solve_wall_time_sec"]=elapsed
        result["solve_time_sec"]=float(timing[-1]) if timing else math.nan
        bound=re.findall(r"(?:Current MIP best bound|Best bound)\s*=\s*([0-9.eE+\-]+)",output,re.I)
        if bound:
            result["bound_centered"]=float(bound[-1]);result["bound_full"]=result["bound_centered"]+result["baseline_constant"]
            result["mip_gap"]=abs(result["objective_centered"]-result["bound_centered"])/(1e-10+abs(result["objective_centered"]))
    elif "status" not in result:
        low=output.lower()
        if "infeasible" in low and "infeasible or unbounded" not in low:
            result.update(status="infeasible",raw_status="CLI reports infeasible; no solution file")
        else:
            result.update(status="solver_error",raw_status="CLI produced no solution file",error=f"No readable solution was produced. Inspect {logfile}")
    return result
