"""Leak-free proxy calibration and correlated-uncertainty reliability experiments.

Run from this directory: python reliability_experiments.py

The historical load-derived coefficients are synthetic, bounded proxy outcomes,
not measured transformer sensitivities. The chronological experiments do not claim
exchangeability or distribution-free finite-sample coverage for the observed year.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import sys
import time
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import numpy as np
import pandas as pd
from scipy.special import ndtr

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
OUTPUTS = ROOT / "outputs"
SECTIONS = ROOT / "sections"
N_TRAIN = 120
N_CAL = 120
EPSILON = 0.05
DELTA = 0.5
N_MC = 10_000
MC_SEED = 20261113
VIOLATION_TOL = 1e-6
FEASIBILITY_TOL = 1e-5
COLORS = {
    "Deterministic": "#0072B2",
    "Slotwise Q75": "#E69F00",
    "Robust": "#009E73",
    "Empirical 90%": "#CC79A7",
    "Empirical 95%": "#56B4E9",
    "Conformal 95%": "#D55E00",
    "Training mean": "#6A3D9A",
    "Training median": "#8C564B",
    "Empirical max 95%": "#666666",
}
CAL_POLICIES = ["Deterministic", "Training mean", "Training median",
                "Empirical 90%", "Empirical 95%", "Empirical max 95%",
                "Conformal 95%", "Robust"]
# Stable internal keys preserve the existing result-builder interface. In the
# upward-proxy experiment the original "Deterministic" schedule is a lower-end
# reference, not a centered forecast. Its display label must make this explicit.
CAL_LABELS = {
    "Deterministic": "Lower-end reference",
    "Training mean": "Training mean",
    "Training median": "Training median",
    "Empirical 90%": "Marginal empirical 90%",
    "Empirical 95%": "Marginal empirical 95%",
    "Empirical max 95%": "Empirical daily-max 95%",
    "Conformal 95%": "Conformal (target 95%)",
    "Robust": "Robust",
}
QUANTILE_IDENTITY_TOL = 1e-12


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def conformal_quantile(scores: np.ndarray, epsilon: float) -> tuple[float, int]:
    """Exact upper split-conformal order statistic, with the +infinity atom.

    Clipping the rank to n would be invalid when epsilon < 1/(n+1).
    No interpolation is used. Ties yield conservative coverage under exchangeability.
    """
    scores = np.sort(np.asarray(scores, dtype=float))
    if scores.ndim != 1 or len(scores) == 0 or not np.isfinite(scores).all():
        raise ValueError("Finite, nonempty one-dimensional calibration scores required")
    if not 0.0 < epsilon < 1.0:
        raise ValueError("epsilon must lie in (0, 1)")
    k = int(math.ceil((len(scores) + 1) * (1.0 - epsilon)))
    return (float(scores[k - 1]) if k <= len(scores) else math.inf), k


def make_proxy_paths() -> tuple[list[str], np.ndarray, np.ndarray, dict]:
    """Fit ECDFs on proper-training days only; then transform every daily outcome."""
    paths = sorted((ROOT / "data").glob("opsd_de_lu_2019_*_profile.csv"))
    dates: list[str] = []
    loads: list[np.ndarray] = []
    for path in paths:
        frame = pd.read_csv(path)
        if len(frame) != 24 or frame["raw_load_mw"].isna().any():
            continue
        dates.append(str(frame["utc_timestamp"].iloc[0])[:10])
        # Use the original hourly load feature, not within-day min/max-scaled L.
        # Daily normalization forces one L=475 per path, hence F_training(L)=1
        # at that hour and an artificial max-score of one on every single day.
        loads.append(frame["raw_load_mw"].to_numpy(float))
    load_matrix = np.stack(loads)
    if len(dates) != 361 or dates != sorted(dates):
        raise ValueError("Expected the 361 chronologically ordered complete 2019 profiles")
    training_sorted = np.sort(load_matrix[:N_TRAIN], axis=0)
    # Right-continuous empirical CDF. No statistics of calibration/test days enter it.
    ranks = np.empty_like(load_matrix)
    for t in range(load_matrix.shape[1]):
        ranks[:, t] = np.searchsorted(training_sorted[:, t], load_matrix[:, t], side="right") / N_TRAIN
    hat = np.full(24, 1.5)
    paths_u = hat[None, :] * (1.0 + DELTA * ranks)
    hashes = {path.name: sha256(path) for path in paths}
    manifest_hash = hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest()
    split_info = {
        "proper_training": {"n": N_TRAIN, "start": dates[0], "end": dates[N_TRAIN - 1]},
        "fixed_calibration": {"n": N_CAL, "start": dates[N_TRAIN], "end": dates[N_TRAIN + N_CAL - 1]},
        "evaluation": {"n": len(dates) - N_TRAIN - N_CAL, "start": dates[N_TRAIN + N_CAL], "end": dates[-1]},
        "source_profile_count": len(paths),
        "source_manifest_sha256": manifest_hash,
        "source_profile_sha256": hashes,
        "ecdf": "right-continuous, <= rank; fit once on first 120 complete daily RAW hourly OPSD load profiles",
        "proxy_formula": "u[s,t] = 1.5 * (1 + 0.5 * F_training,t(raw_load_mw[s,t]))",
        "proxy_support": [1.5, 2.25],
        "nominal_u": hat.tolist(),
        "score_scale_d": (DELTA * hat).tolist(),
        "calibration_feature": "Original raw_load_mw from OPSD; no per-day centering, min/max scaling, or fit on calibration/evaluation days",
        "normalization": "Station L used in optimization retains the original within-day affine scaling to [390,475] kW. Calibration uses separate RAW hourly load features to avoid mechanically forcing a daily CDF maximum of one. Coefficients remain retrospective synthetic proxies, not measured grid sensitivities or forecasts.",
    }
    frame = pd.DataFrame(paths_u, columns=[f"u_{t:02d}" for t in range(1, 25)])
    frame.insert(0, "date", dates)
    frame.insert(1, "split", ["training"] * N_TRAIN + ["calibration"] * N_CAL + ["evaluation"] * (len(dates) - N_TRAIN - N_CAL))
    frame.to_csv(RESULTS / "reliability_proxy_paths.csv", index=False)
    pd.DataFrame(training_sorted, columns=[f"hour_{t:02d}" for t in range(1, 25)]).to_csv(RESULTS / "reliability_training_ecdf_support.csv", index=False)
    return dates, paths_u, hat, split_info


def calibration_coefficients(
    cal_u: np.ndarray, hat: np.ndarray, training_coefficients: dict[str, np.ndarray]
) -> tuple[dict[str, np.ndarray], float, int, float]:
    scale = DELTA * hat
    scores = np.max((cal_u - hat[None, :]) / scale[None, :], axis=1)
    q, k = conformal_quantile(scores, EPSILON)
    # Same daily-max score and calibration window as conformal, but an ordinary
    # interpolated empirical percentile, without the finite-sample rank correction.
    q_empirical_max = float(np.quantile(scores, 1.0 - EPSILON, method="linear"))
    # The n=120 protocol has finite q. Do not silently cap an infinite conformal q.
    if not np.isfinite(q):
        raise ValueError("This experiment requires a finite conformal order statistic")
    coeff = {
        "Deterministic": hat.copy(),
        **{policy: value.copy() for policy, value in training_coefficients.items()},
        "Empirical 90%": np.quantile(cal_u, 0.90, axis=0, method="linear"),
        "Empirical 95%": np.quantile(cal_u, 0.95, axis=0, method="linear"),
        "Empirical max 95%": hat + q_empirical_max * scale,
        "Conformal 95%": hat + q * scale,
        "Robust": (1.0 + DELTA) * hat,
    }
    return coeff, q, k, q_empirical_max


def solution_metrics(sol: dict) -> dict:
    keys = ["objective_full", "objective_linear", "energy_cost", "throughput_cost", "load_smoothing", "objective_centered", "baseline_constant", "simultaneous_residual_raw", "feasibility_residual", "soc_residual"]
    result = {key: float(sol[key]) for key in keys}
    result["charge_kwh"] = float(np.sum(sol["pc"]))
    result["discharge_kwh"] = float(np.sum(sol["pd"]))
    result["solver_status"] = str(sol["status"])
    return result


def evaluate_path(base, sol: dict, coeff: np.ndarray, u: np.ndarray) -> dict:
    pc = np.asarray(sol["pc"], float).reshape(-1)
    excess = np.asarray(base.L, float) + u * pc - float(base.M)
    raw_max = float(np.max(excess))
    coefficient_excess = float(np.max(u - coeff))
    return {
        "capacity_violation": int(raw_max > VIOLATION_TOL),
        "capacity_max_excess_kw": max(raw_max, 0.0),
        "capacity_raw_max_excess_kw": raw_max,
        "coefficient_envelope_violation": int(coefficient_excess > 1e-12),
        "coefficient_envelope_max_excess": max(coefficient_excess, 0.0),
    }


def summarize_calibration(daily: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (protocol, policy), frame in daily.groupby(["protocol", "policy"], sort=False):
        rows.append({
            "protocol": protocol, "policy": policy, "policy_label": CAL_LABELS[policy],
            "n_evaluation_days": len(frame),
            "capacity_violations": int(frame.capacity_violation.sum()),
            "capacity_violation_rate": float(frame.capacity_violation.mean()),
            "max_capacity_excess_kw": float(frame.capacity_max_excess_kw.max()),
            "mean_positive_capacity_excess_kw": float(frame.capacity_max_excess_kw.mean()),
            "coefficient_envelope_violations": int(frame.coefficient_envelope_violation.sum()),
            "coefficient_envelope_violation_rate": float(frame.coefficient_envelope_violation.mean()),
            "coefficient_envelope_coverage": 1.0 - float(frame.coefficient_envelope_violation.mean()),
            **{f"mean_{key}": float(frame[key].mean()) for key in ["objective_full", "objective_linear", "energy_cost", "throughput_cost", "load_smoothing", "objective_centered", "charge_kwh", "discharge_kwh"]},
            "max_simultaneous_residual_raw": float(frame.simultaneous_residual_raw.max()),
            "max_feasibility_residual": float(frame.feasibility_residual.max()),
        })
    return pd.DataFrame(rows)


def independent_violation_probability(base, pc: np.ndarray, lower: np.ndarray, upper: np.ndarray) -> float:
    success = []
    for L, power, lo, hi in zip(base.L, pc, lower, upper):
        if abs(power) <= 1e-8:
            success.append(float(L <= base.M + VIOLATION_TOL))
        else:
            threshold = (base.M + VIOLATION_TOL - L) / power
            # The actual accepted solution has nonnegative powers to numerical tolerance.
            if power < 0:
                raise ValueError("Material negative charging power in raw solver solution")
            success.append(float(np.clip((threshold - lo) / (hi - lo), 0.0, 1.0)))
    return float(1.0 - np.prod(success))


def wilson_interval(k: int, n: int, z: float = 1.959963984540054) -> tuple[float, float]:
    p = k / n
    denominator = 1.0 + z * z / n
    center = (p + z * z / (2 * n)) / denominator
    radius = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denominator
    return max(0.0, center - radius), min(1.0, center + radius)


def plot_results(summary: pd.DataFrame, monthly: pd.DataFrame, correlation: pd.DataFrame,
                 quantile_comparison: pd.DataFrame) -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 12, "axes.titlesize": 13,
        "axes.labelsize": 12, "legend.fontsize": 12, "axes.spines.top": False,
        "axes.spines.right": False, "pdf.fonttype": 42, "ps.fonttype": 42,
        "savefig.bbox": "tight", "savefig.pad_inches": 0.06,
    })
    fig, axes_grid = plt.subplots(2, 2, figsize=(9.5, 9.1),
                                  gridspec_kw={"height_ratios": [1.2, 1.0]},
                                  constrained_layout=True)
    axes = axes_grid.reshape(-1)
    y = np.arange(len(CAL_POLICIES))
    short_labels = ["Lower-end ref.", "Training mean", "Training median",
                    "Marginal 90%", "Marginal 95%", "Daily-max 95%",
                    "Conf. (95% target)", "Robust"]
    axes[1].sharey(axes[0])
    for j, protocol in enumerate(["fixed", "rolling"]):
        frame = summary[summary.protocol.eq(protocol)].set_index("policy").loc[CAL_POLICIES]
        values = [frame.capacity_violations.to_numpy(),
                  frame.coefficient_envelope_coverage.to_numpy() * 100]
        for panel, vals in enumerate(values):
            axes[panel].barh(y + (j - .5) * .44, vals, height=.38,
                            color=[COLORS[p] for p in CAL_POLICIES], alpha=1.0 if j == 0 else .42,
                            edgecolor="black", linewidth=.35, hatch=None if j == 0 else "//")
            for yp, value in zip(y + (j - .5) * .44, vals):
                label = f"{value:.0f}" if panel == 0 else f"{value:.1f}"
                axes[panel].annotate(label, (value, yp), xytext=(3, 0),
                                     textcoords="offset points", va="center", fontsize=12)
    axes[0].set_yticks(y, short_labels, fontsize=12)
    axes[0].invert_yaxis()
    axes[1].tick_params(axis="y", labelleft=False)
    axes[0].set_xlabel("Violating days (out of 121)")
    axes[0].set_title("A. Capacity violations")
    axes[0].set_xlim(0, max(8, summary.capacity_violations.max() * 1.18 + 3))
    axes[0].legend(handles=[Patch(facecolor="0.55", edgecolor="black", linewidth=.4, label="Fixed"),
                           Patch(facecolor="0.8", edgecolor="black", linewidth=.4, hatch="//", label="Rolling")],
                   frameon=False, loc="lower right", fontsize=12)
    axes[1].set_xlabel("Coefficient coverage (%)")
    axes[1].set_title("B. Achieved joint coverage")
    axes[1].set_xlim(0, 113)
    axes[1].axvline(95, color="0.25", linestyle=":", linewidth=1.1)
    # The two joint-envelope methods use identical scores and calibration windows.
    # Thick gray underlays and thin orange overlays expose coincident curves.
    month_order = sorted(monthly.month.unique())
    for policy, width, marker in [("Empirical max 95%", 3.0, "o"),
                                   ("Conformal 95%", 1.4, "^")]:
        for protocol, style in [("fixed", "-"), ("rolling", "--")]:
            f = monthly[monthly.policy.eq(policy) & monthly.protocol.eq(protocol)].set_index("month").loc[month_order]
            axes[2].plot(np.arange(len(month_order)), 100 * (1-f.coefficient_envelope_violation_rate),
                         style, marker=marker, markersize=5, markerfacecolor="white", linewidth=width,
                         color=COLORS[policy], label=f"{policy} / {protocol}")
    axes[2].axhline(95, color="0.25", linestyle=":", linewidth=1.1)
    axes[2].set_xticks(np.arange(len(month_order)), [pd.Timestamp(m + "-01").strftime("%b") for m in month_order])
    axes[2].set_ylabel("Coefficient coverage (%)")
    axes[2].set_title("C. Monthly joint coverage")
    axes[2].set_ylim(35, 104)
    legend_handles = [Line2D([0], [0], color=COLORS["Empirical max 95%"], linewidth=3,
                            marker="o", markerfacecolor="white", markersize=4,
                            label="Empirical daily-max"),
                      Line2D([0], [0], color=COLORS["Conformal 95%"], linewidth=1.5,
                            marker="^", markerfacecolor="white", markersize=4,
                            label="Conformal")]
    legend_handles += [Line2D([0], [0], color="0.3", linestyle="-", label="Fixed"),
                       Line2D([0], [0], color="0.3", linestyle="--", label="Rolling"),
                       Line2D([0], [0], color="0.25", linestyle=":", linewidth=1, label="95% joint reference")]
    axes[2].legend(handles=legend_handles, frameon=False, ncol=2, fontsize=12,
                   loc="upper center", bbox_to_anchor=(.5, -.12), columnspacing=.7, handlelength=1.7)
    q_roll = quantile_comparison[quantile_comparison.protocol.eq("rolling")]
    times = pd.to_datetime(q_roll.date)
    differences = q_roll.conformal_q_minus_empirical_max_q.to_numpy()
    axes[3].plot(times, differences, color=COLORS["Conformal 95%"], linewidth=1.4)
    axes[3].axhline(0, color="0.45", linestyle=":", linewidth=1)
    axes[3].set_xticks([pd.Timestamp(m + "-01") for m in month_order],
                      [pd.Timestamp(m + "-01").strftime("%b") for m in month_order])
    axes[3].set_ylabel("Score threshold difference")
    axes[3].set_title("D. Rolling rank correction")
    axes[3].text(.02, .96, f"Equal on {int(q_roll.same_coefficients.sum())}/121 rolling days",
                 transform=axes[3].transAxes, va="top", fontsize=12)
    axes[3].set_ylim(bottom=-max(.001, .06*max(differences.max(), .001)),
                     top=max(.005, 1.3*differences.max()))
    for i, ax in enumerate(axes):
        ax.grid(axis="x" if i < 2 else "y", color="0.9", linewidth=.6)
        ax.set_axisbelow(True)
    fig.savefig(OUTPUTS / "reliability_calibration.pdf")
    fig.savefig(OUTPUTS / "reliability_calibration.png", dpi=260)
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(8.2, 3.6), constrained_layout=True)
    for ax, context, title in zip(axes, ["base", "multi_slot"],
                                 ["A. Base day: 24 January", "B. Four exposed slots: 23 April"]):
        for policy in ["Deterministic", "Slotwise Q75", "Robust"]:
            f = correlation[correlation.context.eq(context) & correlation.policy.eq(policy)].sort_values("latent_ar1_r")
            x = f.latent_ar1_r.to_numpy()
            ax.plot(x, 100*f.violation_probability, marker="o", linewidth=1.7, markersize=4, color=COLORS[policy], label=policy)
            ax.fill_between(x, 100*f.mc_wilson95_lower, 100*f.mc_wilson95_upper, color=COLORS[policy], alpha=.17, linewidth=0)
        ax.set_title(title)
        ax.set_ylabel("Violation probability (%)")
    for ax in axes:
        ax.set_xlabel("Latent AR(1) parameter")
        ax.set_xticks([0, .3, .6, .9])
        ax.set_ylim(bottom=-1)
        ax.grid(axis="y", color="0.9", linewidth=.6)
        ax.set_axisbelow(True)
    axes[0].legend(frameon=False)
    fig.savefig(OUTPUTS / "reliability_correlation.pdf")
    fig.savefig(OUTPUTS / "reliability_correlation.png", dpi=260)
    plt.close(fig)


def write_results_section(summary: pd.DataFrame, correlation: pd.DataFrame, protocol: dict,
                          monthly: pd.DataFrame) -> None:
    """Generate the manuscript tables and numerical statements from the same CSV data."""
    indexed = summary.set_index(["protocol", "policy"])
    rows = []
    for mode in ["fixed", "rolling"]:
        for policy in CAL_POLICIES:
            row = indexed.loc[(mode, policy)]
            policy_tex = CAL_LABELS[policy].replace("%", r"\%")
            rows.append(
                f"{mode.capitalize()} & {policy_tex} & {row.mean_objective_full:.6f} & "
                f"{row.mean_objective_linear:.6f} & {row.mean_objective_centered:.6f} & "
                f"{int(row.capacity_violations)} & {int(row.coefficient_envelope_violations)} & "
                f"{100*row.coefficient_envelope_coverage:.2f} " + r"\\"
            )
        if mode == "fixed":
            rows.append(r"\midrule")
    corr = correlation.set_index(["context", "policy", "latent_ar1_r"])
    fixed_nom = indexed.loc[("fixed", "Deterministic")]
    fixed_rob = indexed.loc[("fixed", "Robust")]
    fixed90 = indexed.loc[("fixed", "Empirical 90%")]
    fixed95 = indexed.loc[("fixed", "Empirical 95%")]
    fixed_conf = indexed.loc[("fixed", "Conformal 95%")]
    rolling_conf = indexed.loc[("rolling", "Conformal 95%")]
    fixed_mean = indexed.loc[("fixed", "Training mean")]
    fixed_median = indexed.loc[("fixed", "Training median")]
    fixed_max = indexed.loc[("fixed", "Empirical max 95%")]
    rolling_max = indexed.loc[("rolling", "Empirical max 95%")]
    roll90 = indexed.loc[("rolling", "Empirical 90%")]
    roll95 = indexed.loc[("rolling", "Empirical 95%")]
    october = monthly[monthly.month.eq("2019-10")].set_index(["protocol", "policy"])
    same_fixed = protocol["fixed_joint_envelope_coefficient_difference"] <= QUANTILE_IDENTITY_TOL
    median_coefficients = protocol['training_nominal_baselines']['median']
    median_description = (
        f"The training-median coefficient is {min(median_coefficients):.6f} at every hour."
        if max(median_coefficients)-min(median_coefficients) <= QUANTILE_IDENTITY_TOL else
        f"The training-median coefficients range from {min(median_coefficients):.6f} "
        f"to {max(median_coefficients):.6f}."
    )
    fixed_comparison = (
        "The ordinary empirical 95th-percentile daily-max threshold and the conformal "
        "order statistic are identical to the stated numerical tolerance because of tied "
        "calibration scores. They therefore give the same fixed coefficient envelope "
        "and schedule. This fixed experiment demonstrates no distinct numerical benefit "
        "from the finite-sample rank correction."
        if same_fixed else
        "The empirical daily-max and conformal thresholds differ. Their resulting costs "
        "and both kinds of violations are reported separately, so any numerical effect "
        "of the rank correction is distinct from replacing marginal quantiles by a joint score."
    )
    corr_rows = []
    for ar in [0., .3, .6, .9]:
        d = corr.loc[("multi_slot", "Deterministic", ar)]
        q = corr.loc[("multi_slot", "Slotwise Q75", ar)]
        r = corr.loc[("multi_slot", "Robust", ar)]
        corr_rows.append(f"{ar:.1f} & {d.violation_probability:.4f} & {q.violation_probability:.4f} & "
                         f"{r.violation_probability:.4f} & {d.mean_positive_capacity_excess_kw:.3f} & "
                         f"{q.mean_positive_capacity_excess_kw:.3f} " + r"\\")
    text = r"""\subsection{Calibration without future information}
\label{subsec:revised_calibration_results}

The main calibration finding is undercoverage of the nominal 95\% joint target.
The fixed and rolling conformal envelopes cover only @@FCCOVER@@\% and
@@RCCOVER@@\% of the 121 evaluation paths, with @@FCENV@@ and @@RCENV@@
joint-envelope misses, respectively. Their scheduled capacity-violation counts
are @@FCCAP@@ and @@RCCAP@@. These smaller operational counts do not establish
95\% coefficient coverage: an envelope can be exceeded when the EV is not
charging or when the schedule retains capacity slack. The results diagnose
limited temporal transfer in this constructed proxy experiment; they do not
contradict the conformal theorem under its exchangeability assumption.

All eight fixed-context schedules charge only in slot 21. Of the fixed conformal
envelope's @@FCENV@@ misses, \OriginalConfInactiveMisses{} occur outside positive
charging, and the remaining @@FCCAP@@ coincide with capacity events. This narrow
exposure motivates the predetermined multi-slot controls and binding fleet
comparison below; the base-day result alone does not establish broad transfer.

The proper-training, calibration, and evaluation ranges are 1 January--4 May,
5 May--1 September, and 2 September--31 December 2019, respectively (120, 120,
and 121 complete daily paths). The observed feature is original hourly OPSD
load in MW, whereas the operating station load remains separately scaled and
fixed at the base-day context. Table~\ref{tab:revised_calibration} distinguishes
centered point-estimate baselines, per-hour marginal quantiles, and joint
daily-max envelopes; their statistical targets are not interchangeable.

\begin{table}[htbp]
\centering
\small
\setlength{\tabcolsep}{3.5pt}
\caption{Leak-free proxy evaluation at the fixed base-day operating context.
The cost columns report the mean full objective $J$, linear energy-plus-throughput
component $C_{\mathrm{lin}}$, and centered objective $J-J_0$; $J$ is EUR-equivalent
and $C_{\mathrm{lin}}$ is in EUR. ``Cap.'' and
``Env.'' count daily capacity violations and joint coefficient-envelope misses,
respectively, out of 121 days. Coverage is observed joint coefficient coverage.
The 95\% label is a target for the daily-max policies, not an achieved guarantee.
Training-only mean/median schedules remain frozen in both protocols.}
\label{tab:revised_calibration}
\begin{tabular}{llrrrrrr}
\toprule
Protocol & Policy & $J$ & $C_{\mathrm{lin}}$ & $J-J_0$ & Cap. & Env. & Cov. (\%)\\
\midrule
@@CALIBRATION_ROWS@@
\bottomrule
\end{tabular}
\end{table}

The original coefficient 1.5 is the proxy support's lower endpoint, so its
@@NOMENV@@/121 envelope misses are largely structural. This lower-end reference
has @@NOMCOUNT@@ capacity violations. The frozen training-mean and training-median
baselines instead have @@MEANCAP@@ and @@MEDIANCAP@@ capacity violations, and
joint coefficient coverage of @@MEANCOVER@@\% and @@MEDIANCOVER@@\%.
The training-mean coefficients range from @@MEANMIN@@ to @@MEANMAX@@.
@@MEDIAN_DESCRIPTION@@ Thus comparison with the lower endpoint alone
does not isolate an advantage over a centered point estimate. Under fixed
calibration, the marginal empirical 90\% and 95\% schedules record @@F90CAP@@
and @@F95CAP@@ capacity violations, with @@F90ENV@@ and @@F95ENV@@ envelope
misses; these are marginal, not daily joint, quantile targets.

The fixed empirical daily-max threshold is @@QMAXFIXED@@ and the conformal
threshold is $q=@@QFIXED@@$, giving a conformal coefficient of @@CONFFIXED@@
at every hour, compared with the robust coefficient 2.25.
@@FIXED_COMPARISON@@
The rolling thresholds coincide on @@ROLLSAME@@ of 121 evaluation days; the mean
and maximum conformal-minus-empirical score corrections are @@ROLLQMEAN@@ and
@@ROLLQMAX@@. Rolling empirical daily-max protection has @@RMAXCAP@@ capacity
violations and @@RMAXENV@@ envelope misses, compared with @@RCCAP@@ and
@@RCENV@@ for conformal. These matched comparisons separate a correction to
the order statistic from the larger change between marginal and joint protection.

The rolling conformal quantiles range from @@QMIN@@ to @@QMAX@@.
In October alone, fixed and rolling conformal envelopes miss @@OCTFIX@@ and
@@OCTROLL@@ of 31 days. Rolling calibration therefore does not restore the
nominal coverage target. The archive retains the complete daily/monthly coverage
and threshold diagnostics and their figures.
Raw hourly features remove the artificial daily-maximum score caused by
within-day min--max normalization, but do not establish exchangeability or
identify measured grid-impact coefficients.

Relative to the frozen training-mean schedule, robust protection increases
$J$ by @@JPREMIUMMEAN@@ EUR-equivalent and $C_{\rm lin}$ by @@CPREMIUMMEAN@@ EUR;
the smoothing component decreases. Relative to the lower-end reference, these
increments are @@JPREMIUM@@ and @@CPREMIUM@@, respectively. These quantities
are model-objective tradeoffs, not estimates of a deployment's electricity bill.
Zero observed capacity violations remain sample outcomes; the separate robust
certificate applies to every coefficient vector within the prescribed support.

\FloatBarrier
\subsection{Dependence beyond the independent-uniform calculation}
\label{subsec:revised_correlation_results}

The base-day nominal and Slotwise Q75 schedules each have only one charging slot
with nonzero violation probability. Their true joint risk therefore depends only
on that slot's marginal distribution and is unaffected by temporal dependence;
the small Monte Carlo differences in Figure~\ref{fig:revised_correlation}A are
sampling variation. To expose a nontrivial dependence effect, we additionally use
the 23 April 2019 load and tariff profile, keeping all EV parameters unchanged.
This day is deliberately selected as the largest nominal joint-risk case in the
original complete-year stress benchmark, not as a representative or independent
validation sample. The nominal and Slotwise Q75 schedules have four exposed
charging slots on this day.

At $r=0$, their independent-product probabilities are @@DEXACT@@ and @@QEXACT@@,
compared with Monte Carlo estimates @@DMC@@ and @@QMC@@. When the latent AR(1)
parameter increases to 0.9, the estimates become @@DCORR@@ and @@QCORR@@
(Table~\ref{tab:revised_correlation}). In this case positive dependence clusters
the exceedances and reduces the probability of at least one exceedance. This
is a property of the tested distribution and schedules, not a general monotonicity
theorem for correlated uncertainty. Robust protection remains feasible throughout
the prescribed box, independently of the temporal coupling; its zero Monte Carlo
count is consistent with that deterministic certificate.

\begin{table}[htbp]
\centering
\small
\caption{Temporally correlated uniform stress test on the selected 23 April
profile. Violation probabilities use 10,000 simulated daily paths. The final
two columns give the mean positive maximum daily capacity excess (kW).}
\label{tab:revised_correlation}
\begin{tabular}{rrrrrr}
\toprule
$r$ & Nominal risk & Q75 risk & Robust risk & Nominal excess & Q75 excess\\
\midrule
@@CORRELATION_ROWS@@
\bottomrule
\end{tabular}
\end{table}

\begin{figure}[htbp]
\centering
\includegraphics[width=\textwidth]{outputs/reliability_correlation.pdf}
\caption{Effect of temporal dependence with unchanged uniform marginals.
The base day has one exposed charging slot; the selected 23 April stress day has
four. Shaded bands are 95\% Wilson intervals for Monte Carlo sampling error across
10,000 independent daily paths, not uncertainty about real grid-impact data.}
\label{fig:revised_correlation}
\end{figure}
"""
    values = {
        "@@CALIBRATION_ROWS@@": "\n".join(rows), "@@CORRELATION_ROWS@@": "\n".join(corr_rows),
        "@@NOMCOUNT@@": str(int(fixed_nom.capacity_violations)), "@@NOMRATE@@": f"{100*fixed_nom.capacity_violation_rate:.2f}",
        "@@NOMENV@@": str(int(fixed_nom.coefficient_envelope_violations)),
        "@@MEANCAP@@": str(int(fixed_mean.capacity_violations)),
        "@@MEDIANCAP@@": str(int(fixed_median.capacity_violations)),
        "@@MEANCOVER@@": f"{100*fixed_mean.coefficient_envelope_coverage:.2f}",
        "@@MEDIANCOVER@@": f"{100*fixed_median.coefficient_envelope_coverage:.2f}",
        "@@MEANMIN@@": f"{min(protocol['training_nominal_baselines']['mean']):.6f}",
        "@@MEANMAX@@": f"{max(protocol['training_nominal_baselines']['mean']):.6f}",
        "@@MEDIANMIN@@": f"{min(protocol['training_nominal_baselines']['median']):.6f}",
        "@@MEDIANMAX@@": f"{max(protocol['training_nominal_baselines']['median']):.6f}",
        "@@MEDIAN_DESCRIPTION@@": median_description,
        "@@F90CAP@@": str(int(fixed90.capacity_violations)), "@@F95CAP@@": str(int(fixed95.capacity_violations)),
        "@@F90ENV@@": str(int(fixed90.coefficient_envelope_violations)), "@@F95ENV@@": str(int(fixed95.coefficient_envelope_violations)),
        "@@FCCAP@@": str(int(fixed_conf.capacity_violations)), "@@RCCAP@@": str(int(rolling_conf.capacity_violations)),
        "@@FCENV@@": str(int(fixed_conf.coefficient_envelope_violations)), "@@RCENV@@": str(int(rolling_conf.coefficient_envelope_violations)),
        "@@FCCOVER@@": f"{100*fixed_conf.coefficient_envelope_coverage:.2f}",
        "@@RCCOVER@@": f"{100*rolling_conf.coefficient_envelope_coverage:.2f}",
        "@@QMAXFIXED@@": f"{protocol['fixed_empirical_max_q']:.6f}",
        "@@FIXED_COMPARISON@@": fixed_comparison,
        "@@ROLLSAME@@": str(protocol['rolling_joint_envelope_equal_days']),
        "@@ROLLQMEAN@@": f"{protocol['rolling_joint_envelope_mean_q_difference']:.6f}",
        "@@ROLLQMAX@@": f"{protocol['rolling_joint_envelope_max_q_difference']:.6f}",
        "@@RMAXCAP@@": str(int(rolling_max.capacity_violations)),
        "@@RMAXENV@@": str(int(rolling_max.coefficient_envelope_violations)),
        "@@OCTFIX@@": str(int(october.loc[('fixed','Conformal 95%'),'coefficient_envelope_violations'])),
        "@@OCTROLL@@": str(int(october.loc[('rolling','Conformal 95%'),'coefficient_envelope_violations'])),
        "@@QFIXED@@": f"{protocol['fixed_conformal_q']:.6f}", "@@CONFFIXED@@": f"{1.5 + .75*protocol['fixed_conformal_q']:.6f}",
        "@@QMIN@@": f"{protocol['rolling_conformal_q_min']:.6f}", "@@QMAX@@": f"{protocol['rolling_conformal_q_max']:.6f}",
        "@@JPREMIUM@@": f"{fixed_rob.mean_objective_full-fixed_nom.mean_objective_full:.6f}",
        "@@CPREMIUM@@": f"{fixed_rob.mean_objective_linear-fixed_nom.mean_objective_linear:.6f}",
        "@@JPREMIUMMEAN@@": f"{fixed_rob.mean_objective_full-fixed_mean.mean_objective_full:.6f}",
        "@@CPREMIUMMEAN@@": f"{fixed_rob.mean_objective_linear-fixed_mean.mean_objective_linear:.6f}",
        "@@R90COST@@": f"{roll90.mean_objective_linear:.6f}", "@@R95COST@@": f"{roll95.mean_objective_linear:.6f}",
        "@@R90COUNT@@": str(int(roll90.capacity_violations)), "@@R95COUNT@@": str(int(roll95.capacity_violations)),
        "@@R90RATE@@": f"{100*roll90.capacity_violation_rate:.2f}", "@@R95RATE@@": f"{100*roll95.capacity_violation_rate:.2f}",
        "@@DEXACT@@": f"{corr.loc[('multi_slot','Deterministic',0.),'independent_closed_form_probability']:.6f}",
        "@@QEXACT@@": f"{corr.loc[('multi_slot','Slotwise Q75',0.),'independent_closed_form_probability']:.6f}",
        "@@DMC@@": f"{corr.loc[('multi_slot','Deterministic',0.),'violation_probability']:.4f}",
        "@@QMC@@": f"{corr.loc[('multi_slot','Slotwise Q75',0.),'violation_probability']:.4f}",
        "@@DCORR@@": f"{corr.loc[('multi_slot','Deterministic',.9),'violation_probability']:.4f}",
        "@@QCORR@@": f"{corr.loc[('multi_slot','Slotwise Q75',.9),'violation_probability']:.4f}",
    }
    for key, value in values.items():
        text = text.replace(key, value)
    if "@@" in text:
        raise RuntimeError("Unfilled numerical placeholder in generated results section")
    (SECTIONS / "reliability_results.tex").write_text(text, encoding="utf-8")


def regenerate_reports() -> None:
    """Regenerate figures and TeX from saved results without importing a solver.

    The numerical CSVs and original run protocol remain unchanged. A separate
    record ties the reporting source to the preserved source used for that run.
    """
    protocol_path = RESULTS / "reliability_protocol.json"
    protocol = json.loads(protocol_path.read_text(encoding="utf-8"))
    snapshot = ROOT / protocol.get("source_snapshot", "results/reliability_fullrun_source_snapshot.py")
    current_source = Path(__file__)
    if not snapshot.exists() or sha256(snapshot) != protocol["script_sha256"]:
        if sha256(current_source) != protocol["script_sha256"]:
            raise RuntimeError("Preserve the source matching the full-run protocol before reporting-only edits")
        snapshot.write_bytes(current_source.read_bytes())
    protected = sorted(RESULTS.glob("reliability_*.csv")) + [
        protocol_path, RESULTS / "reliability_operating_cases.json", snapshot,
    ]
    before = {str(path.relative_to(ROOT)): sha256(path) for path in protected}
    summary = pd.read_csv(RESULTS / "reliability_calibration_summary.csv")
    monthly = pd.read_csv(RESULTS / "reliability_calibration_monthly.csv")
    correlation = pd.read_csv(RESULTS / "reliability_correlation_summary.csv")
    quantiles = pd.read_csv(RESULTS / "reliability_calibration_quantile_comparison.csv")
    plot_results(summary, monthly, correlation, quantiles)
    write_results_section(summary, correlation, protocol, monthly)
    after = {str(path.relative_to(ROOT)): sha256(path) for path in protected}
    if before != after:
        raise RuntimeError("A numerical result or original provenance record changed during report regeneration")
    report_paths = [OUTPUTS / f"reliability_{family}.{ext}"
                    for family in ["calibration", "correlation"] for ext in ["pdf", "png"]]
    report_paths += [SECTIONS / "reliability_results.tex"]
    note = {
        "operation": "Reporting-only print-readability and float-order repair; no optimization",
        "created_utc": pd.Timestamp.now(tz="UTC").isoformat(),
        "command": "python reliability_experiments.py --reports-only",
        "full_run_source_snapshot": str(snapshot.relative_to(ROOT)),
        "full_run_source_sha256": protocol["script_sha256"],
        "reporting_script_sha256": sha256(current_source),
        "numerical_results_and_original_protocol_unchanged": before == after,
        "preserved_files_sha256": after,
        "report_outputs_sha256": {str(path.relative_to(ROOT)): sha256(path) for path in report_paths},
        "changes": [
            "Minimum chart text raised to 12 source points; calibration canvas made taller and labels shortened for at least 7 points at manuscript width",
            "Correlation canvas narrowed to improve printed type size",
            "FloatBarrier inserted before the dependence subsection so the calibration figure cannot interrupt its prose",
        ],
    }
    (RESULTS / "reliability_reporting_update.json").write_text(
        json.dumps(note, indent=2, ensure_ascii=False), encoding="utf-8")
    print("Regenerated two PDF/PNG figures and reliability results text from saved data; no solver imported.")
    print("Numerical files and original run protocol unchanged; source snapshot and hashes recorded.")


def run() -> None:
    import ev_robust_charging as ev
    import revision_model as engine

    for directory in [RESULTS, OUTPUTS, SECTIONS]:
        directory.mkdir(parents=True, exist_ok=True)
    source_hash = sha256(Path(__file__))
    source_snapshot = RESULTS / "provenance" / "reliability_sources" / (source_hash + ".py")
    source_snapshot.parent.mkdir(parents=True, exist_ok=True)
    source_snapshot.write_bytes(Path(__file__).read_bytes())
    start = time.perf_counter()
    dates, u, hat, split = make_proxy_paths()
    training_coefficients = {
        "Training mean": np.mean(u[:N_TRAIN], axis=0),
        "Training median": np.median(u[:N_TRAIN], axis=0),
    }
    pd.DataFrame({
        "hour": np.arange(1, len(hat)+1), "n_training_days": N_TRAIN,
        "training_start": dates[0], "training_end": dates[N_TRAIN-1],
        "training_mean_coefficient": training_coefficients["Training mean"],
        "training_median_coefficient": training_coefficients["Training median"],
        "lower_end_coefficient": hat, "box_upper_coefficient": (1+DELTA)*hat,
    }).to_csv(RESULTS / "reliability_training_baselines.csv", index=False)
    base = ev.build_base_case()
    cache: dict[bytes, dict] = {}
    solve_log: list[dict] = []

    def solve(coeff: np.ndarray, data=base) -> dict:
        coeff = np.asarray(coeff, float)
        key = data.profile_date.encode() + b"|" + coeff.tobytes()
        if key not in cache:
            sol = engine.solve_case(engine.from_legacy(data), coeff=coeff, solver="CPLEX", binary=False)
            if sol["status"] not in {"optimal", "optimal_inaccurate"}:
                raise RuntimeError(f"Reliability QP failed: {sol['status']}")
            if float(sol["feasibility_residual"]) > FEASIBILITY_TOL:
                raise RuntimeError(f"Reliability QP raw feasibility residual {sol['feasibility_residual']} exceeds {FEASIBILITY_TOL}")
            cache[key] = sol
            solve_log.append({"unique_qp": len(cache), "profile_date": data.profile_date, "case_coefficient_sha256": hashlib.sha256(key).hexdigest(), **solution_metrics(sol)})
        return cache[key]

    first_test = N_TRAIN + N_CAL
    coeff_fixed, q_fixed, k_fixed, q_max_fixed = calibration_coefficients(
        u[N_TRAIN:first_test], hat, training_coefficients)
    fixed_solutions = {policy: solve(coeff_fixed[policy]) for policy in CAL_POLICIES}
    daily_rows: list[dict] = []
    coefficient_rows: list[dict] = []
    quantile_rows: list[dict] = []
    for index in range(first_test, len(dates)):
        rolling_coeff, q_rolling, k_rolling, q_max_rolling = calibration_coefficients(
            u[index - N_CAL:index], hat, training_coefficients)
        for protocol, coeffs, q, k, q_max, cal_start, cal_end in [
            ("fixed", coeff_fixed, q_fixed, k_fixed, q_max_fixed, N_TRAIN, first_test - 1),
            ("rolling", rolling_coeff, q_rolling, k_rolling, q_max_rolling, index - N_CAL, index - 1),
        ]:
            quantile_rows.append({
                "protocol": protocol, "date": dates[index],
                "calibration_start": dates[cal_start], "calibration_end": dates[cal_end],
                "n_calibration": N_CAL, "empirical_max_q": q_max,
                "conformal_q": q, "conformal_order": k,
                "conformal_q_minus_empirical_max_q": q-q_max,
                "max_coefficient_difference": float(np.max(np.abs(
                    coeffs["Conformal 95%"]-coeffs["Empirical max 95%"]))),
                "same_coefficients": bool(np.allclose(
                    coeffs["Conformal 95%"], coeffs["Empirical max 95%"],
                    rtol=0, atol=QUANTILE_IDENTITY_TOL)),
            })
            for policy in CAL_POLICIES:
                sol = solve(coeffs[policy])
                if policy in training_coefficients:
                    source = "proper-training point estimate, frozen"
                    fit_start, fit_end = dates[0], dates[N_TRAIN-1]
                elif policy in {"Deterministic", "Robust"}:
                    source = "prescribed support endpoint, fixed"
                    fit_start, fit_end = None, None
                else:
                    source = "calibration outcomes only"
                    fit_start, fit_end = dates[cal_start], dates[cal_end]
                daily_rows.append({
                    "protocol": protocol, "policy": policy, "policy_label": CAL_LABELS[policy],
                    "date": dates[index], "coefficient_source": source,
                    "coefficient_fit_start": fit_start, "coefficient_fit_end": fit_end,
                    "calibration_start": dates[cal_start], "calibration_end": dates[cal_end],
                    "n_calibration": N_CAL, "conformal_q": q if policy == "Conformal 95%" else np.nan,
                    "conformal_order": k if policy == "Conformal 95%" else np.nan,
                    "empirical_max_q": q_max if policy == "Empirical max 95%" else np.nan,
                    **solution_metrics(sol), **evaluate_path(base, sol, coeffs[policy], u[index]),
                })
                coefficient_rows.append({"protocol": protocol, "policy": policy,
                                         "policy_label": CAL_LABELS[policy], "date": dates[index],
                                         **{f"coefficient_{t+1:02d}": float(c) for t, c in enumerate(coeffs[policy])}})
        if (index - first_test + 1) % 30 == 0:
            print(f"Processed {index - first_test + 1}/121 evaluation days; {len(cache)} unique calibration QPs", flush=True)

    daily = pd.DataFrame(daily_rows)
    daily.to_csv(RESULTS / "reliability_calibration_daily.csv", index=False)
    pd.DataFrame(coefficient_rows).to_csv(RESULTS / "reliability_calibration_coefficients.csv", index=False)
    quantile_comparison = pd.DataFrame(quantile_rows)
    quantile_comparison.to_csv(RESULTS / "reliability_calibration_quantile_comparison.csv", index=False)
    summary = summarize_calibration(daily)
    summary.to_csv(RESULTS / "reliability_calibration_summary.csv", index=False)
    monthly = daily.assign(month=daily.date.str[:7]).groupby(["protocol", "policy", "month"], sort=False).agg(
        n_days=("date", "size"), capacity_violations=("capacity_violation", "sum"),
        capacity_violation_rate=("capacity_violation", "mean"),
        coefficient_envelope_violations=("coefficient_envelope_violation", "sum"),
        coefficient_envelope_violation_rate=("coefficient_envelope_violation", "mean"),
        mean_objective_full=("objective_full", "mean"), mean_objective_linear=("objective_linear", "mean"),
    ).reset_index()
    monthly["policy_label"] = monthly.policy.map(CAL_LABELS)
    monthly["coefficient_envelope_coverage"] = 1-monthly.coefficient_envelope_violation_rate
    monthly.to_csv(RESULTS / "reliability_calibration_monthly.csv", index=False)

    lower = (1.0 - DELTA) * hat
    upper = (1.0 + DELTA) * hat
    corr_coeffs = {"Deterministic": hat, "Slotwise Q75": lower + .75*(upper-lower), "Robust": upper}
    # The second day deliberately stresses multiple exposed charging slots. It is
    # the highest nominal joint-risk day in the original 361-day stress benchmark,
    # not an independent validation sample or a claim of representative frequency.
    corr_cases = {"base": base, "multi_slot": ev.build_case_from_profile("2019-04-23")}
    corr_solutions = {context: {policy: solve(coeff, data) for policy, coeff in corr_coeffs.items()}
                      for context, data in corr_cases.items()}
    standard_normals = np.random.default_rng(MC_SEED).standard_normal((N_MC, len(hat)))
    correlation_rows = []
    for ar in [0.0, 0.3, 0.6, 0.9]:
        z = np.empty_like(standard_normals)
        z[:, 0] = standard_normals[:, 0]
        for t in range(1, len(hat)):
            z[:, t] = ar*z[:, t-1] + math.sqrt(1.0-ar*ar)*standard_normals[:, t]
        sampled_u = lower + (upper-lower)*ndtr(z)
        for context, data in corr_cases.items():
            for policy, sol in corr_solutions[context].items():
                pc = np.asarray(sol["pc"]).reshape(-1)
                excess = np.max(np.asarray(data.L)[None, :] + sampled_u * pc[None, :] - data.M, axis=1)
                count = int(np.sum(excess > VIOLATION_TOL))
                lo_ci, hi_ci = wilson_interval(count, N_MC)
                exact_independent = independent_violation_probability(data, pc, lower, upper)
                thresholds = np.divide(data.M - data.L, pc, out=np.full_like(pc, np.inf), where=pc > 1e-7)
                exposed_slots = (pc > 1e-7) & (thresholds < upper - 1e-8)
                correlation_rows.append({
                    "context": context, "profile_date": data.profile_date, "policy": policy,
                    "latent_ar1_r": ar, "n_mc_paths": N_MC, "mc_seed": MC_SEED,
                    "positive_charge_slots": int(np.sum(pc > 1e-7)), "exposed_charge_slots": int(exposed_slots.sum()),
                    "violation_count": count, "violation_probability": count / N_MC,
                    "mc_wilson95_lower": lo_ci, "mc_wilson95_upper": hi_ci,
                    "mean_positive_capacity_excess_kw": float(np.maximum(excess, 0).mean()),
                    "sample_max_capacity_excess_kw": float(np.maximum(excess, 0).max()),
                    "box_worst_case_excess_kw": max(float(np.max(data.L + upper*pc-data.M)), 0.0),
                    "independent_closed_form_probability": exact_independent if ar == 0 else np.nan,
                    "absolute_mc_error_at_independence": abs(count/N_MC-exact_independent) if ar == 0 else np.nan,
                    **solution_metrics(sol),
                })
    correlation = pd.DataFrame(correlation_rows)
    correlation.to_csv(RESULTS / "reliability_correlation_summary.csv", index=False)
    schedule_rows = []
    for family, solutions, coeffs in [("fixed_calibration", fixed_solutions, coeff_fixed),
                                     ("correlation_base", corr_solutions["base"], corr_coeffs),
                                     ("correlation_multi_slot", corr_solutions["multi_slot"], corr_coeffs)]:
        for policy, sol in solutions.items():
            pc, pd_ = np.asarray(sol["pc"]).reshape(-1), np.asarray(sol["pd"]).reshape(-1)
            energy = np.asarray(sol["energy"]).reshape(-1)
            for t in range(len(hat)):
                schedule_rows.append({"family": family, "policy": policy, "hour": t+1, "coefficient": coeffs[policy][t],
                                      "pc_raw_kw": pc[t], "pd_raw_kw": pd_[t], "energy_before_kwh": energy[t], "energy_after_kwh": energy[t+1]})
    pd.DataFrame(schedule_rows).to_csv(RESULTS / "reliability_raw_schedules.csv", index=False)
    (RESULTS / "reliability_operating_cases.json").write_text(json.dumps(
        {context: engine.serialize_case(engine.from_legacy(data)) for context, data in corr_cases.items()},
        indent=2), encoding="utf-8")
    pd.DataFrame(solve_log).to_csv(RESULTS / "reliability_qp_diagnostics.csv", index=False)
    plot_results(summary, monthly, correlation, quantile_comparison)

    protocol = {
        "experiment": "Leak-free synthetic coefficient-proxy calibration and temporally correlated uniform stress tests",
        "created_utc": pd.Timestamp.now(tz="UTC").isoformat(),
        "python": sys.version, "platform": platform.platform(),
        "numpy": np.__version__, "pandas": pd.__version__,
        "elapsed_seconds": time.perf_counter()-start,
        "script_sha256": source_hash, "source_snapshot": str(source_snapshot.relative_to(ROOT)),
        "source_unchanged_during_run": sha256(Path(__file__)) == source_hash,
        "engine_sha256": sha256(ROOT / "revision_model.py"),
        **split,
        "policy_display_labels": CAL_LABELS,
        "training_nominal_baselines": {
            "fit_start": dates[0], "fit_end": dates[N_TRAIN-1], "n_days": N_TRAIN,
            "mean": training_coefficients["Training mean"].tolist(),
            "median": training_coefficients["Training median"].tolist(),
            "protocol": "Per-hour point estimates of proper-training proxy coefficients only; frozen in both fixed and rolling evaluation; no claim of probability-envelope coverage or physical forecasting validation",
        },
        "lower_end_reference": "Internal policy key Deterministic is retained for builder compatibility; in the upward-proxy experiment uhat=1.5 is the lower support endpoint, not a centered nominal forecast",
        "fixed_conformal_q": q_fixed, "fixed_conformal_order": k_fixed,
        "fixed_empirical_max_q": q_max_fixed,
        "fixed_joint_envelope_coefficient_difference": float(np.max(np.abs(
            coeff_fixed["Conformal 95%"]-coeff_fixed["Empirical max 95%"]))),
        "rolling_joint_envelope_equal_days": int(quantile_comparison.loc[
            quantile_comparison.protocol.eq("rolling"), "same_coefficients"].sum()),
        "rolling_joint_envelope_mean_q_difference": float(quantile_comparison.loc[
            quantile_comparison.protocol.eq("rolling"), "conformal_q_minus_empirical_max_q"].mean()),
        "rolling_joint_envelope_max_q_difference": float(quantile_comparison.loc[
            quantile_comparison.protocol.eq("rolling"), "conformal_q_minus_empirical_max_q"].max()),
        "quantile_identity_absolute_tolerance": QUANTILE_IDENTITY_TOL,
        "rolling_conformal_q_min": float(daily.loc[daily.protocol.eq("rolling") & daily.policy.eq("Conformal 95%"), "conformal_q"].min()),
        "rolling_conformal_q_max": float(daily.loc[daily.protocol.eq("rolling") & daily.policy.eq("Conformal 95%"), "conformal_q"].max()),
        "epsilon_joint_conformal": EPSILON,
        "empirical_quantiles": "numpy linear interpolation, marginal per hour; not finite-sample joint protection",
        "empirical_daily_max_quantile": "numpy linear 95th percentile of the same daily-max calibration scores used for conformal, without finite-sample rank correction; no claimed finite-sample guarantee",
        "conformal_quantile": "k=ceil((n+1)*(1-epsilon)); q=kth sorted score, +infinity if k=n+1",
        "rolling_protocol": "Same proper-training ECDF and training-only mean/median baselines are frozen; before each evaluation day, recalibrate marginal quantiles, empirical daily-max quantile, and conformal quantile on the preceding 120 complete observed days, including earlier evaluation outcomes only after observed. No future outcomes used.",
        "operating_context": "All proxy evaluations hold the 2019-01-24 base-day load, prices, EV parameters fixed. These are fixed-context uncertainty stress tests, not deployment replay.",
        "coverage_claim": "No exact finite-sample guarantee claimed for chronological OPSD-derived proxy paths; exchangeability is not established. Monthly results are descriptive.",
        "score_event": "Joint daily coefficient-envelope miss is distinct from downstream capacity violation; reported separately.",
        "correlation": {"marginal_distribution": "Uniform on [0.75,2.25] independently of latent AR parameter", "latent_ar1_parameters": [0,.3,.6,.9], "n_paths": N_MC, "seed": MC_SEED, "common_random_numbers": True, "ci": "95% Wilson intervals across independent simulated whole-day paths; they quantify Monte Carlo error only", "contexts": {"base": "2019-01-24", "multi_slot": "2019-04-23"}, "stress_day_selection": "April23 is deliberately selected as the largest nominal joint-risk day in the original complete-year stress benchmark. Original EV parameters remain unchanged. This is not an unbiased test sample."},
        "capacity_violation_tolerance_kw": VIOLATION_TOL,
        "raw_solution_feasibility_acceptance_tolerance": FEASIBILITY_TOL,
        "raw_solution_postprocessing": "No clipping or zeroing of charging, discharging, or SOC before diagnostics/evaluation",
        "unique_qp_solves": len(cache),
        "all_solver_statuses": sorted(set(daily.solver_status)),
        "max_raw_simultaneous_residual": max(row["simultaneous_residual_raw"] for row in solve_log),
        "max_raw_feasibility_residual": max(row["feasibility_residual"] for row in solve_log),
    }
    (RESULTS / "reliability_protocol.json").write_text(json.dumps(protocol, indent=2, ensure_ascii=False), encoding="utf-8")
    write_results_section(summary, correlation, protocol, monthly)
    print(summary[["protocol", "policy", "capacity_violation_rate", "coefficient_envelope_violation_rate", "mean_objective_full", "mean_objective_linear"]].to_string(index=False), flush=True)
    print(correlation[["context", "policy", "latent_ar1_r", "violation_probability", "mean_positive_capacity_excess_kw"]].to_string(index=False), flush=True)
    print(f"Saved reliability results; {len(cache)} unique QPs in {protocol['elapsed_seconds']:.2f}s", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reports-only", action="store_true",
                        help="Regenerate figures and results text from saved outputs without optimization")
    args = parser.parse_args()
    if args.reports_only:
        regenerate_reports()
    else:
        run()
