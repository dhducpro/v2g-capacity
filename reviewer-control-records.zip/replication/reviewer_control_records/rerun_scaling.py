from pathlib import Path
import csv,json
import pandas as pd
from run_revision import isolated_solve,summarize_scaling,load_instance
from experiment_utils import environment
rows=[]
for f in sorted(Path('scaling_instances').glob('*.json')):
 case=load_instance(f)
 for policy in ('Deterministic','Robust'):
  for binary in (False,True):
   out=Path('logs')/f'{f.stem}_{policy}_{binary}.json'
   sol=isolated_solve(f.resolve(),out.resolve(),'CPLEX_EXE',binary,policy,30)
   row={**sol,'N':case.N,'T':case.T,'seed':int(f.stem.split('seed')[-1]),'policy':policy,'case':case.name,'binary':binary}
   rows.append(row);print(case.name,policy,binary,sol.get('status'),flush=True)
   pd.DataFrame(rows).to_csv('results/scaling_raw.csv',index=False)
frame = pd.DataFrame(rows)
summary = []
for (n,t,policy), group in frame.groupby(["N","T","policy"]):
    qp = group[~group.binary].set_index("seed").sort_index()
    miqp = group[group.binary].set_index("seed").sort_index()
    if not qp.index.equals(miqp.index) or not (group.status == "optimal").all():
        raise RuntimeError(f"Incomplete optimal pairs for {n}, {t}, {policy}")
    summary.append(dict(N=n,T=t,policy=policy,pairs=len(qp),
                        mean_qp_elapsed_s=qp.solve_wall_time_sec.mean(),
                        mean_miqp_elapsed_s=miqp.solve_wall_time_sec.mean(),
                        median_paired_ratio=(miqp.solve_wall_time_sec/qp.solve_wall_time_sec).median(),
                        mean_qp_rss_mib=qp.peak_rss_mb.mean(),mean_miqp_rss_mib=miqp.peak_rss_mb.mean()))
pd.DataFrame(summary).to_csv("results/scaling_elapsed_summary.csv",index=False)
Path('results/scaling_environment.json').write_text(json.dumps(environment(),indent=2))
