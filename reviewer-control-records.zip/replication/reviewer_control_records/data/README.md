Public data used by `ev_robust_charging.py`
==========================================

Source: Open Power System Data, Time series data package, version 2020-10-06.

URL: https://data.open-power-system-data.org/time_series/2020-10-06/

Citation recommended by OPSD:

Open Power System Data. 2020. Data Package Time series. Version 2020-10-06.
https://doi.org/10.25832/time_series/2020-10-06.

Files:

- `opsd_de_lu_2019_01.csv`: cached DE-LU hourly load and day-ahead price data for January 2019.
- `opsd_de_lu_2019_01_24_profile.csv`: 24-hour profile used in the EV/V2G experiments.
- `../caltech.csv`: local session-level Caltech ACN export used by the fleet experiments. The code reads `Start`, `End`, and `Energy` as plug-in time, unplug time, and delivered energy, respectively. No ACN API token is required.

Transformations:

- Raw DE-LU load is affinely scaled to the station baseload interval [390, 475].
- Raw day-ahead price in EUR/MWh is converted to EUR/kWh.
- EV charging price is `max(raw_price, 1) / 1000`.
- V2G selling price is `0.98 * charging_price`.
- OPSD timestamps are selected by UTC date and retain the CET/CEST timestamp. Caltech session timestamps are interpreted in `America/Los_Angeles` local time, so the combined experiment is a public-data stress test rather than a same-site replay.
