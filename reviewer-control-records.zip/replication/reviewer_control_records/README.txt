CPLEX controls for Supplementary Sections S1-S3

Run these commands from this folder with IBM ILOG CPLEX Studio 22.1.2 and its Python API installed.
Set V2G_CPLEX_EXE to the full CPLEX Studio executable for the scaling benchmark.

python run_revision.py --suite edge --edge-solver CPLEX
python run_revision.py --suite station
python reliability_experiments.py
python masked_calibration.py
python rerun_scaling.py

The results directory contains the Windows rerun records. scaling_elapsed_summary.csv uses the wall time of the executable, including model read and solution write. The worker also records the lower-precision time printed by CPLEX. The annual OPSD input, daily profiles, processed Caltech sessions and fixed scaling instances are supplied.
