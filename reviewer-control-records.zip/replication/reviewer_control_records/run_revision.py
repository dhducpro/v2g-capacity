"""Reproduce the revised paper. All numerical evidence is regenerated, not patched.

Run from any directory: python run_revision.py --suite station|edge|fleet|scaling|all
The independently executable reliability_experiments.py supplies calibration tests.
"""
from __future__ import annotations
import argparse
from dataclasses import replace, asdict
from pathlib import Path
import json
import os
import subprocess
import sys
import time
import warnings
import numpy as np
import pandas as pd
import cvxpy as cp
import ev_robust_charging as legacy
from revision_model import Case, from_legacy, solve_case, certificate_min
from experiment_utils import (ROOT, PALETTE, POLICIES, FEAS_TOL, COMP_TOL,
                              dump_json, sha256, environment, scalar_metrics,
                              station_violation, fleet_risk, setup_plotting)

RESULTS=ROOT/'results'
FIGURES=ROOT/'outputs'
CASES=RESULTS/'instances'
ACCEPTED_OPTIMAL={'optimal','gaplimit'}  # SCIP gaplimit is accepted only at the configured 1e-8 gap.
for p in [RESULTS,FIGURES,CASES,ROOT/'logs']:
    p.mkdir(exist_ok=True,parents=True)

def save_instance(case,path):
    dump_json(path,asdict(case))

def load_instance(path):
    return Case(**json.loads(Path(path).read_text()))

def checkpoint(rows,name):
    pd.DataFrame(rows).to_csv(RESULTS/name,index=False)

def record(case,sol,**extra):
    row=scalar_metrics(sol)
    row.update({'case':case.name,'N':case.N,'T':case.T,'dt':case.dt,
                'alpha':case.alpha,'M':case.M,'rho_min':float(np.min(case.rho)),
                'certificate_min':float(certificate_min(case)),**extra})
    if sol.get('pc') is not None:
        row.update({'charge_kwh':float(case.dt*np.sum(sol['pc'])),
                    'discharge_kwh':float(case.dt*np.sum(sol['pd'])),
                    'min_net_load':float(np.min(sol['net_load']))})
    return row

def robust_min_capacity(case):
    """LP, exact primary objective M. No hidden quadratic tie-breaker."""
    n,t=case.N,case.T
    x=cp.Variable((n,t),nonneg=True)
    y=cp.Variable((n,t),nonneg=True)
    e=cp.Variable((n,t+1))
    m=cp.Variable()
    eta_c=np.asarray(case.eta_c).reshape(n,1)
    eta_d=np.asarray(case.eta_d).reshape(n,1)
    constraints=[x<=case.Pc[:,None]*case.availability,
                 y<=case.Pd[:,None]*case.availability,
                 e[:,0]==case.E0,
                 e[:,1:]==e[:,:-1]+case.dt*(cp.multiply(eta_c,x)-cp.multiply(1/eta_d,y)),
                 e[:,1:]>=case.Emin[:,None],e[:,1:]<=case.Emax[:,None],
                 e[:,-1]>=case.Etarget,
                 case.L+cp.sum(cp.multiply(1.5*case.u_nominal,x),axis=0)<=m,
                 m>=float(np.max(case.L))]
    problem=cp.Problem(cp.Minimize(m),constraints)
    problem.solve(solver='CPLEX')
    if problem.status!='optimal':
        raise RuntimeError(f'Capacity LP failed: {problem.status}')
    return float(m.value)

def run_station():
    base=from_legacy(legacy.build_base_case())
    rows=[]
    for delta in [0.,.1,.2,.3,.4,.5]:
        for policy,factor0 in POLICIES.items():
            factor=1+delta*(2*(factor0-1))
            sol=solve_case(base,coeff=factor*base.u_nominal,solver='CPLEX')
            row=record(base,sol,delta=delta,policy=policy)
            if sol.get('pc') is not None:
                row['joint_violation']=station_violation(base,sol['pc'],delta)
                row['worst_case_excess']=float(np.max(base.L+np.sum((1+delta)*base.u_nominal*sol['pc'],axis=0)-base.M))
            rows.append(row)
            if delta==.5:
                np.savez_compressed(RESULTS/f"station_{policy.lower().replace(' ','_')}.npz",
                                    pc=sol['pc'],pd=sol['pd'],energy=sol['energy'])
    checkpoint(rows,'station_delta.csv')
    pd.DataFrame(rows).query('delta==0.5').to_csv(RESULTS/'station_base.csv',index=False)
    sensitivities=[]
    # Published case-specific battery-throughput cost outcomes are used only as
    # scale anchors, not as a calibrated aging model. This conversion equalizes
    # the penalty of an SOC-preserving cycle: (1+k)*rho = 2*eta_c*c_b.
    k0=float(base.eta_c[0]*base.eta_d[0])
    reference_penalties={float(2*base.eta_c[0]*cb/(1+k0)):cb for cb in [.0023,.0045]}
    rho_values=sorted([0.,.0005,.001,.002,.005,.01,.02]+list(reference_penalties))
    for parameter,values in [('alpha',[0.,1e-4,2e-4,4e-4,8e-4]),
                             ('rho',rho_values)]:
        for value in values:
            case=replace(base,**{parameter:float(value) if parameter=='alpha' else np.full(base.N,value)})
            for policy,factor in POLICIES.items():
                sol=solve_case(case,coeff=factor*case.u_nominal,solver='CPLEX')
                sensitivities.append(record(case,sol,parameter=parameter,value=value,policy=policy,
                    penalty_source=('published_case_scale' if parameter=='rho' and value in reference_penalties else 'exploratory'),
                    battery_reference_eur_kwh=reference_penalties.get(value,np.nan) if parameter=='rho' else np.nan))
    checkpoint(sensitivities,'station_sensitivity.csv')
    daily=[]
    days=legacy.available_profile_dates_2019()
    for j,date in enumerate(days):
        case=from_legacy(legacy.build_case_from_profile(date))
        for policy,factor in POLICIES.items():
            sol=solve_case(case,coeff=factor*case.u_nominal,solver='CPLEX')
            row=record(case,sol,date=date,policy=policy)
            if sol.get('pc') is not None:
                row['joint_violation']=station_violation(case,sol['pc'])
            daily.append(row)
        if (j+1)%40==0: print(f'station days {j+1}/{len(days)}',flush=True)
    checkpoint(daily,'station_multiday.csv')
    data=pd.DataFrame(daily)
    data.groupby('policy').agg(days=('case','size'),mean_full=('objective_full','mean'),
        mean_centered=('objective_centered','mean'),mean_linear=('objective_linear','mean'),
        mean_discharge=('discharge_kwh','mean'),mean_violation=('joint_violation','mean'),
        max_violation=('joint_violation','max'),max_raw_residual=('simultaneous_residual_raw','max'),
        max_feasibility=('feasibility_residual','max')).to_csv(RESULTS/'station_multiday_summary.csv')
    plt=setup_plotting()
    fig,axs=plt.subplots(1,2,figsize=(7.1,2.7),layout='constrained')
    frame=pd.DataFrame(rows)
    for policy in POLICIES:
        d=frame[frame.policy.eq(policy)]
        axs[0].plot(100*d.delta,d.objective_centered,'o-',label=policy,color=PALETTE[policy],lw=1.7,ms=4)
        axs[1].plot(100*d.delta,100*d.joint_violation,'o-',label=policy,color=PALETTE[policy],lw=1.7,ms=4)
    axs[0].set(xlabel='Uncertainty radius (%)',ylabel='Centered full objective (EUR-eq.)')
    axs[1].set(xlabel='Uncertainty radius (%)',ylabel='Joint violation probability (%)')
    for ax in axs: ax.grid(alpha=.18)
    axs[0].legend(frameon=False)
    fig.savefig(FIGURES/'station_sensitivity.pdf')
    fig.savefig(FIGURES/'station_sensitivity.png',dpi=200)
    plt.close(fig)
    print('station complete',flush=True)

def pair(case,solver,group,policy='Deterministic',factor=1.,capacity_mode='charging',export_limit=None,**extra):
    results={}
    # Same solver and mathematically identical objective for the paired formulations.
    for binary in [False,True]:
        sol=solve_case(case,coeff=factor*case.u_nominal,solver=solver,binary=binary,
                       capacity_mode=capacity_mode,export_limit=export_limit,time_limit=60,threads=1)
        results['miqp' if binary else 'qp']=sol
    q,m=results['qp'],results['miqp']
    row={'group':group,'policy':policy,'capacity_mode':capacity_mode,'case':case.name,
         'N':case.N,'T':case.T,'dt':case.dt,'alpha':case.alpha,'rho':float(np.min(case.rho)),
         'certificate_min':float(certificate_min(case)),**extra}
    for prefix,s in results.items():
        row.update({f'{prefix}_{k}':v for k,v in scalar_metrics(s).items()})
        if s.get('pc') is not None:
            row[f'{prefix}_min_net_load']=float(np.min(s['net_load']))
    if q.get('objective_full') is not None and m.get('objective_full') is not None:
        gap=m['objective_full']-q['objective_full']
        row['objective_gap']=gap
        row['relative_centered_gap']=gap/max(1.,abs(m['objective_centered']))
    r=q.get('simultaneous_residual_raw',np.nan)
    both_opt=(str(q.get('status')).lower() in ACCEPTED_OPTIMAL and str(m.get('status')).lower() in ACCEPTED_OPTIMAL)
    if both_opt:
        tol=1e-5*max(1.,abs(m['objective_centered']))
        row['gap_failure']=bool(row['objective_gap']>tol)
        row['simultaneous_above_1e6']=bool(r>COMP_TOL)
    else:
        row['gap_failure']=None
        row['simultaneous_above_1e6']=None
    return row,results

def run_edge(solver='CPLEX'):
    base=from_legacy(legacy.build_base_case())
    baseline=[]
    for old in legacy.build_extended_miqp_validation_cases(legacy.build_base_case()):
        case=from_legacy(old)
        for policy,factor in POLICIES.items():
            row,_=pair(case,solver,'certified_baseline',policy=policy,factor=factor)
            baseline.append(row)
    checkpoint(baseline,'exactness_baseline.csv')
    raw=pd.read_csv(ROOT/'data'/'opsd_de_lu_2019.csv')
    raw['day']=pd.to_datetime(raw.utc_timestamp,utc=True).dt.strftime('%Y-%m-%d')
    price=raw['DE_LU_price_day_ahead']
    complete=set(legacy.available_profile_dates_2019())
    negative_days=sorted(set(raw.loc[price.lt(0),'day']) & complete)
    dump_json(RESULTS/'price_audit.json',{'observed_prices':int(price.notna().sum()),
        'negative_hours':int(price.lt(0).sum()),'below_1_hours':int(price.lt(1).sum()),
        'negative_days_complete':len(negative_days),'minimum_eur_mwh':float(price.min()),
        'complete_days':len(complete),'complete_hours':24*len(complete),
        'negative_hour_fraction_complete':int(raw.loc[raw.day.isin(complete),'DE_LU_price_day_ahead'].lt(0).sum())/(24*len(complete))})
    rows=[]
    for j,date in enumerate(negative_days):
        case0=from_legacy(legacy.build_case_from_profile(date))
        p=raw.loc[raw.day.eq(date),'DE_LU_price_day_ahead'].to_numpy(float)/1000
        for alpha in [0.,2e-4]:
            for rho in [0.,.001]:
                for spread in [0.,.01]:
                    case=replace(case0,name=f'raw_{date}_a{alpha:g}_r{rho:g}_s{spread:g}',alpha=alpha,
                                 rho=np.array([rho]),price_buy=p+spread/2,price_sell=p-spread/2)
                    row,_=pair(case,solver,'historical_negative',date=date,spread=spread,
                               active_negative_hours=int(np.count_nonzero((p<0)&(case.availability[0]>0))))
                    rows.append(row)
        checkpoint(rows,'edge_historical_raw.csv')
        print(f'negative-price days {j+1}/{len(negative_days)}',flush=True)
    frame=pd.DataFrame(rows)
    frame.groupby(['alpha','rho','spread'],dropna=False).agg(
        pairs=('case','size'),gap_failures=('gap_failure','sum'),
        simultaneous=('simultaneous_above_1e6','sum'),
        max_gap=('objective_gap','max'),mean_gap=('objective_gap','mean'),
        max_raw_residual=('qp_simultaneous_residual_raw','max'),
        certified=('certificate_min',lambda x:int(np.sum(x>0)))).to_csv(RESULTS/'edge_historical_summary.csv')
    stress=[]
    for shift in [0.,400.,450.,500.,600.]:
        for alpha in [0.,2e-4,2e-3]:
            for rho in [0.,.001]:
                for mode in ['charging','net_import']:
                    case=replace(base,name=f'surplus_shift{shift:g}_a{alpha:g}_r{rho:g}',
                                 L=base.L-shift,availability=np.ones((1,24)),
                                 E0=np.array([75.]),Etarget=np.array([75.]),
                                 price_buy=np.full(24,.03),price_sell=np.full(24,.0294),
                                 rho=np.array([rho]),alpha=alpha,M=475.)
                    row,_=pair(case,solver,'controlled_surplus',capacity_mode=mode,load_shift=shift)
                    stress.append(row)
    checkpoint(stress,'edge_export_raw.csv')
    simple=replace(base,name='export_bound_counterexample',T=1,L=np.array([-2.]),
        availability=np.ones((1,1)),price_buy=np.array([.03]),price_sell=np.array([.0294]),
        u_nominal=np.array([[1.5]]),E0=np.array([50.]),Etarget=np.array([50.]),
        Emax=np.array([50.]),Emin=np.array([0.]),alpha=0.)
    counter=[]
    for mode in ['charging','net_import','two_sided']:
        row,_=pair(simple,solver,'export_bound_counterexample',capacity_mode=mode,export_limit=1.)
        counter.append(row)
    # A constructed negative-price case with ηcηd<1 isolates profitable loss cycling.
    negative=replace(simple,name='negative_price_counterexample',L=np.array([0.]),
                     price_buy=np.array([-.1]),price_sell=np.array([-.1]),rho=np.array([0.]))
    row,_=pair(negative,solver,'negative_price_counterexample')
    counter.append(row)
    # Zero objective: value exactness can coexist with non-complementary optimal points.
    degenerate=replace(simple,name='zero_objective',L=np.array([0.]),price_buy=np.array([0.]),
                       price_sell=np.array([0.]),rho=np.array([0.]))
    row,_=pair(degenerate,solver,'zero_objective')
    counter.append(row)
    checkpoint(counter,'edge_counterexamples.csv')
    all_rows=baseline+rows+stress+counter
    checkpoint(all_rows,'edge_all.csv')
    plt=setup_plotting()
    fig,axs=plt.subplots(1,2,figsize=(7.1,2.8),layout='constrained')
    a=frame[frame.spread.eq(0)&frame.rho.eq(.001)].copy()
    for alpha,color,label in [(0.,'#0072B2',r'$\alpha=0$'),(2e-4,'#D55E00',r'$\alpha=2\times10^{-4}$')]:
        z=a[a.alpha.eq(alpha)].sort_values('date')
        axs[0].plot(np.arange(len(z)),np.maximum(z.objective_gap,0),'o',ms=3,color=color,label=label)
    axs[0].set(xlabel='Negative-price day (chronological index)',ylabel='MIQP minus QP objective (EUR-eq.)')
    axs[0].legend(frameon=False)
    z=pd.DataFrame(stress)
    z=z[z.capacity_mode.eq('charging')&z.rho.eq(.001)]
    for alpha,color,label in [(0.,'#0072B2',r'$\alpha=0$'),(2e-4,'#E69F00',r'$\alpha=2\times10^{-4}$'),(2e-3,'#D55E00',r'$\alpha=2\times10^{-3}$')]:
        v=z[z.alpha.eq(alpha)].sort_values('load_shift')
        axs[1].plot(v.load_shift,np.maximum(v.objective_gap,0),'o-',ms=3,color=color,label=label)
    axs[1].set(xlabel='Constructed net-baseload subtraction (kW)',ylabel='MIQP minus QP objective (EUR-eq.)')
    axs[1].legend(frameon=False)
    for ax in axs: ax.grid(alpha=.18)
    fig.savefig(FIGURES/'exactness_boundaries.pdf')
    fig.savefig(FIGURES/'exactness_boundaries.png',dpi=200)
    plt.close(fig)
    print('edge complete',flush=True)

def acn_inputs():
    base=legacy.build_base_case()
    sessions=legacy.load_acn_sessions('caltech','2019-01-01','2019-03-31',2.,ROOT/'caltech.csv')
    dates=legacy.feasible_acn_horizon_dates(sessions,base,'caltech',60,20)
    return base,sessions,dates

def run_fleet():
    base,sessions,dates=acn_inputs()
    config=legacy.FleetExperimentConfig(acn_cache=str(ROOT/'caltech.csv'))
    rows=[]; capacities=[]; parameters=[]
    for j,seed in enumerate(legacy.FLEET_SEEDS):
        old=legacy.build_fleet_case_for_experiment(base,20,seed,config,sessions,dates)
        case0=from_legacy(old)
        m=robust_min_capacity(case0)
        capacities.append({'seed':seed,'horizon_date':old.horizon_date,'M_rob_min':m,'N':20})
        save_instance(case0,CASES/f'fleet_seed_{seed}.json')
        for i in range(case0.N):
            parameters.append({'seed':seed,'horizon_date':old.horizon_date,'vehicle':i,
                'Pc':case0.Pc[i],'Pd':case0.Pd[i],'E0':case0.E0[i],
                'Emin':case0.Emin[i],'Emax':case0.Emax[i],'Etarget':case0.Etarget[i],
                'eta_c':case0.eta_c[i],'eta_d':case0.eta_d[i],
                'availability':';'.join(map(str,np.flatnonzero(case0.availability[i]).tolist()))})
        draws=np.random.default_rng(seed+1701).random((10000,case0.N,case0.T))
        for gamma in [0.,.02,.05,.1,.15]:
            case=replace(case0,M=(1+gamma)*m+1e-4)
            for policy,factor in POLICIES.items():
                sol=solve_case(case,coeff=factor*case.u_nominal,solver='CPLEX')
                row=record(case,sol,seed=seed,horizon_date=old.horizon_date,capacity_gamma=gamma,
                           policy=policy,M_rob_min=m,capacity_buffer=1e-4)
                if sol.get('pc') is not None: row.update(fleet_risk(case,sol['pc'],draws))
                rows.append(row)
        checkpoint(rows,'fleet_capacity_raw.csv')
        print(f'fleet {j+1}/20 date={old.horizon_date}',flush=True)
    checkpoint(capacities,'fleet_capacity_thresholds.csv')
    checkpoint(parameters,'fleet_parameters.csv')
    dump_json(RESULTS/'fleet_protocol.json',{'filtered_sessions':len(sessions),'horizon_dates':dates,
        'seeds':list(legacy.FLEET_SEEDS),'uncertainty_delta':.5,'mc_samples':10000,
        'mc_dependence':'independent across vehicles and slots','feasibility_tolerance_kw':FEAS_TOL,
        'capacity_buffer_kw':1e-4,'capacity_primary_objective':'minimum M LP, no tie-breaker',
        'sampling_unit':'ACN-derived horizon/seed case; no claim of iid replicates'})
    frame=pd.DataFrame(rows)
    ref=frame[frame.policy.eq('Deterministic')][['seed','capacity_gamma','objective_linear','objective_full','objective_centered']]
    ref=ref.rename(columns={c:f'det_{c}' for c in ['objective_linear','objective_full','objective_centered']})
    frame=frame.merge(ref,on=['seed','capacity_gamma'])
    frame['linear_premium']=frame.objective_linear-frame.det_objective_linear
    frame['full_premium']=frame.objective_full-frame.det_objective_full
    frame.to_csv(RESULTS/'fleet_capacity_raw.csv',index=False)
    summary=frame.groupby(['capacity_gamma','policy']).agg(
        cases=('seed','size'),mean_violation=('violation_probability','mean'),
        sd_violation=('violation_probability','std'),min_violation=('violation_probability','min'),
        max_violation=('violation_probability','max'),
        mean_full=('objective_full','mean'),mean_linear=('objective_linear','mean'),
        mean_centered=('objective_centered','mean'),mean_linear_premium=('linear_premium','mean'),
        sd_linear_premium=('linear_premium','std'),mean_full_premium=('full_premium','mean'),
        sd_full_premium=('full_premium','std'),max_comp=('simultaneous_residual_raw','max'),
        max_feasibility=('feasibility_residual','max'),max_wc_excess=('worst_case_excess','max')).reset_index()
    summary.to_csv(RESULTS/'fleet_capacity_summary.csv',index=False)
    plt=setup_plotting()
    fig,axs=plt.subplots(1,2,figsize=(7.1,2.9),layout='constrained')
    for policy in POLICIES:
        s=summary[summary.policy.eq(policy)]
        x=100*s.capacity_gamma.to_numpy()
        mean=s.mean_violation.to_numpy();sd=s.sd_violation.to_numpy()
        axs[0].plot(x,100*mean,'o-',label=policy,color=PALETTE[policy],lw=1.7,ms=4)
        axs[0].fill_between(x,100*np.clip(mean-sd,0,1),100*np.clip(mean+sd,0,1),color=PALETTE[policy],alpha=.15)
        mean=s.mean_full_premium.to_numpy();sd=s.sd_full_premium.to_numpy()
        axs[1].plot(x,mean,'o-',label=policy,color=PALETTE[policy],lw=1.7,ms=4)
        axs[1].fill_between(x,mean-sd,mean+sd,color=PALETTE[policy],alpha=.15)
    axs[0].set(xlabel='Capacity margin (%)',ylabel='Joint violation probability (%)')
    axs[1].set(xlabel='Capacity margin (%)',ylabel='Full-objective premium (EUR-eq.)')
    for ax in axs: ax.grid(alpha=.18)
    axs[0].legend(frameon=False)
    fig.savefig(FIGURES/'fleet_capacity.pdf')
    fig.savefig(FIGURES/'fleet_capacity.png',dpi=200)
    plt.close(fig)
    print('fleet complete',flush=True)

def resampled_fleet(base_pool,n,t,seed):
    """Scaling templates, not a claim of observing n simultaneous real EVs."""
    rng=np.random.default_rng(seed)
    idx=rng.integers(0,base_pool.N,size=n)
    factor=n/20
    repeat=t//24
    if repeat*24!=t: raise ValueError('T must be a multiple of 24')
    return replace(base_pool,name=f'scaling_N{n}_T{t}_seed{seed}',N=n,T=t,dt=1/repeat,
        L=np.repeat(base_pool.L*factor,repeat),
        availability=np.repeat(base_pool.availability[idx],repeat,axis=1),
        price_buy=np.repeat(base_pool.price_buy[idx],repeat,axis=1),
        price_sell=np.repeat(base_pool.price_sell[idx],repeat,axis=1),
        u_nominal=np.repeat(base_pool.u_nominal[idx],repeat,axis=1),
        Pc=base_pool.Pc[idx],Pd=base_pool.Pd[idx],E0=base_pool.E0[idx],
        Emin=base_pool.Emin[idx],Emax=base_pool.Emax[idx],Etarget=base_pool.Etarget[idx],
        eta_c=base_pool.eta_c[idx],eta_d=base_pool.eta_d[idx],rho=base_pool.rho[idx],
        alpha=base_pool.alpha/factor,M=base_pool.M*factor)

def isolated_solve(case_file,out_file,solver,binary,policy,time_limit):
    cmd=[sys.executable,str(ROOT/'solver_worker.py'),'--case',str(case_file),'--output',str(out_file),
         '--solver',solver,'--policy',policy,'--time-limit',str(time_limit)]
    if binary: cmd.append('--binary')
    env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
    if out_file.exists(): out_file.unlink()
    proc=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,text=True,timeout=time_limit+120)
    log=out_file.with_suffix('.log')
    log.write_text(proc.stdout+'\n'+proc.stderr)
    if proc.returncode!=0 or not out_file.exists():
        return {'status':'worker_error','return_code':proc.returncode,'error':proc.stderr[-2000:]}
    return json.loads(out_file.read_text())

def run_scaling(solver='SCIP',pilot=False,time_limit=30):
    base,sessions,dates=acn_inputs()
    pool=from_legacy(legacy.build_fleet_from_acn_sessions(sessions,dates[0],base,
                        n_vehicles=20,seed=90210,site='caltech',cache_path=ROOT/'caltech.csv'))
    configs=[(20,24)] if pilot else [(20,24),(50,24),(100,24),(200,24),(20,96)]
    seeds=[3101] if pilot else [3101,3102,3103,3104,3105]
    rows=[]
    for n,t in configs:
        for seed in seeds:
            case0=resampled_fleet(pool,n,t,seed)
            m=robust_min_capacity(case0)
            case=replace(case0,M=m*1.02+1e-4)
            instance=CASES/f'{case.name}.json'
            save_instance(case,instance)
            for policy in ['Deterministic','Robust']:
                pair_rows={}
                for binary in [False,True]:
                    stem=f'{case.name}_{policy}_{solver}_{"MIQP" if binary else "QP"}'
                    output=ROOT/'logs'/f'{stem}.json'
                    s=isolated_solve(instance,output,solver,binary,policy,time_limit)
                    row={**s,'N':n,'T':t,'dt':case.dt,'seed':seed,'instance_seed':seed,
                         'solver_seed':s.get('seed',0),'policy':policy,
                         'binary':binary,'case':case.name,'M':case.M,'M_rob_min':m,
                         'certificate_min':certificate_min(case)}
                    rows.append(row);pair_rows['miqp' if binary else 'qp']=row
                    print(f'scaling {n}x{t} seed{seed} {policy} binary={binary}: {s.get("status")}',flush=True)
                    checkpoint(rows,'scaling_pilot.csv' if pilot else 'scaling_raw.csv')
    if not pilot:
        summarize_scaling(pd.DataFrame(rows))
    dump_json(RESULTS/('scaling_pilot_protocol.json' if pilot else 'scaling_protocol.json'),
              {'solver':solver,'time_limit_seconds':time_limit,'threads':1,'seeds':seeds,
               'configurations':configs,'horizon_hours':24,'warm_start':False,
               'instance_source':'resampling 20 ACN-derived session templates, synthetic scaling',
               'load_scaling':'N/20','alpha_scaling':'20/N',
               'capacity':'1.02 M_rob_min + 1e-4 kW',
               'memory':'fresh isolated process per formulation; process RSS includes interpreter and solver',
               'environment':environment()})

def summarize_scaling(frame):
    rows=[]
    for keys,g in frame.groupby(['N','T','policy']):
        q=g[~g.binary].set_index('seed',verify_integrity=True).sort_index()
        m=g[g.binary].set_index('seed',verify_integrity=True).sort_index()
        if not q.index.equals(m.index):
            raise ValueError(f'Unmatched instance seeds in scaling group {keys}')
        good=q.status.isin(ACCEPTED_OPTIMAL)&m.status.isin(ACCEPTED_OPTIMAL)
        ratio=m.loc[good,'solve_time_sec']/q.loc[good,'solve_time_sec']
        gaps=m.loc[good,'objective_centered']-q.loc[good,'objective_centered']
        rows.append({'N':keys[0],'T':keys[1],'policy':keys[2],'pairs':len(q),
            'both_optimal':int(good.sum()),'qp_optimal':int(q.status.isin(ACCEPTED_OPTIMAL).sum()),
            'miqp_optimal':int(m.status.isin(ACCEPTED_OPTIMAL).sum()),
            'mean_qp_s':q.loc[q.status.isin(ACCEPTED_OPTIMAL),'solve_time_sec'].mean(),
            'mean_miqp_s':m.loc[m.status.isin(ACCEPTED_OPTIMAL),'solve_time_sec'].mean(),
            'median_paired_ratio':ratio.median(),'max_abs_objective_gap':gaps.abs().max(),
            'mean_qp_rss_mb':q.peak_rss_mb.mean(),'mean_miqp_rss_mb':m.peak_rss_mb.mean(),
            'max_qp_comp':q.simultaneous_residual_raw.max()})
    summary=pd.DataFrame(rows)
    summary.to_csv(RESULTS/'scaling_summary.csv',index=False)
    plt=setup_plotting()
    fig,axs=plt.subplots(1,2,figsize=(7.1,2.8),layout='constrained')
    s=summary[summary['T'].eq(24)]
    for policy,ls in [('Deterministic','-'),('Robust','--')]:
        z=s[s.policy.eq(policy)].sort_values('N')
        for mode,color in [('qp','#0072B2'),('miqp','#D55E00')]:
            axs[0].plot(z.N,z[f'mean_{mode}_s'],'o'+ls,color=color,label=f'{mode.upper()} {policy}',ms=4)
            axs[1].plot(z.N,z[f'mean_{mode}_rss_mb'],'o'+ls,color=color,ms=4)
    axs[0].set(xlabel='Number of EVs',ylabel='Mean successful solver time (s)',yscale='log')
    axs[1].set(xlabel='Number of EVs',ylabel='Mean peak process RSS (MiB)')
    axs[0].legend(frameon=False,fontsize=7)
    for ax in axs:ax.grid(alpha=.18)
    fig.savefig(FIGURES/'scalability.pdf')
    fig.savefig(FIGURES/'scalability.png',dpi=200)
    plt.close(fig)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--suite',choices=['station','edge','fleet','scaling','all'],default='all')
    p.add_argument('--edge-solver',default='CPLEX')
    p.add_argument('--scaling-solver',default='SCIP')
    p.add_argument('--pilot',action='store_true')
    p.add_argument('--time-limit',type=float,default=30.)
    args=p.parse_args()
    os.chdir(ROOT)
    start=time.time()
    dump_json(RESULTS/f'run_{args.suite}_metadata.json',{'arguments':vars(args),'environment':environment(),
        'start_unix':start,'code_sha256':{n:sha256(ROOT/n) for n in ['run_revision.py','revision_model.py','experiment_utils.py','ev_robust_charging.py']},
        'data_sha256':{n:sha256(ROOT/n) for n in ['data/opsd_de_lu_2019.csv','caltech.csv']}})
    if args.suite in ['station','all']:run_station()
    if args.suite in ['edge','all']:run_edge(args.edge_solver)
    if args.suite in ['fleet','all']:run_fleet()
    if args.suite in ['scaling','all']:run_scaling(args.scaling_solver,args.pilot,args.time_limit)
    print(f'Finished {args.suite} in {time.time()-start:.2f} seconds',flush=True)

if __name__=='__main__':main()
