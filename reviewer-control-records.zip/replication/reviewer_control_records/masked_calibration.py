from pathlib import Path
import numpy as np
import pandas as pd

results = Path("results")
paths = pd.read_csv(results / "reliability_proxy_paths.csv")
u = paths.filter(regex="^u_").to_numpy()
rows = []
for start in range(240, len(paths)):
    for protocol, begin in (("fixed", 120), ("rolling", start - 120)):
        for name, slots in (("All-hour", slice(None)), ("Available", slice(10, 21))):
            scores = ((u[:, slots] - 1.5) / 0.75).max(axis=1)
            sample = scores[begin:begin + 120]
            cutoff = np.sort(sample)[114]
            rows.append(dict(protocol=protocol, date=paths.date[start], score_mask=name,
                             conformal_q=cutoff, empirical_q=np.quantile(sample,0.95),
                             miss=bool(scores[start] > cutoff + 1e-10)))
out = pd.DataFrame(rows)
out.to_csv(results / "masked_calibration.csv", index=False)
print(out.groupby(["protocol","score_mask"]).miss.sum())
